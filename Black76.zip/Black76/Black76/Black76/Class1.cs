﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using QLNet;
//using MathNet.Numerics.Distributions;

namespace PricingModel
{
    
    public class GBlackScholes
    {
        /// <summary>
        /// CDF of Normal Distribution
        /// </summary>
        protected static double CN(double X)
        {
            double L = 0.0;
            double K = 0.0;
            double a1 = 0.31938153;
            double a2 = -0.356563782;
            double a3 = 1.781477937;
            double a4 = -1.821255978;
            double a5 = 1.330274429;
            double val = 0.0;
            double Pi = 3.141592653;
            L = Math.Abs(X);
            K = 1 / (1 + 0.2316419 * L);
            val = 1.0 - (1.0 / Math.Sqrt(2 * Pi)) * Math.Exp(-L * L / 2.0) * (a1 * K + a2 * K * K + a3 * K * K * K + a4 * K * K * K * K + a5 * K * K * K * K * K);

            if (X < 0.0)
                val = 1.0 - val;

            return val;
        }
        /// <summary>
        /// PDF of Normal Distribution
        /// </summary>
        protected static double N(double X)
        {
            double Pi = 3.141592653;
            double val = Math.Exp(-X * X / 2.0) / Math.Sqrt(2.0 * Pi);
            return val;
        }

        /// <summary>
        /// BS_Delta
        /// </summary>
        protected static double BS_Delta(int cp, double S, double K, double r, double b, double v, double T)
        {
            double d1 = (Math.Log(S / K) + (r - b) + 0.5 * v * v * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double delta = _cp * Math.Exp(-b * T) * CN(_cp * d1);
            return delta;
        }

        /// <summary>
        /// BS_Gamma
        /// </summary>
        protected static double BS_Gamma(int cp, double S, double K, double r, double b, double v, double T)
        {
            double d1 = (Math.Log(S / K) + (r - b) + 0.5 * v * v * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double gamma = Math.Exp(-b * T) * N(d1) / (S * v * Math.Sqrt(T));
            return gamma;
        }

        /// <summary>
        /// BS_ImpVol
        /// </summary>
        protected static double BS_ImpVol(double wrr, double accuracy, int cp, double S, double K, double r, double b, double v, double T)
        {
            if (S <= 0.0 || K <= 0.0 || T <= 0.0 || r < 0 || wrr.Equals(Double.NaN) || wrr <= 0.0 || accuracy <= 0)
                return 99.9;

            double Vmin = 0.01, Vmax = 2, Vmid = (Vmin + Vmax) / 2;
            double Fmin = GBlackScholes.BS_Price(cp, S, K, r, b, Vmin, T) - wrr;
            double Fmax = GBlackScholes.BS_Price(cp, S, K, r, b, Vmax, T) - wrr;
            double Fmid = GBlackScholes.BS_Price(cp, S, K, r, b, Vmid, T) - wrr;

            do
            {
                if (Fmin * Fmid < 0)
                {
                    Vmax = Vmid;
                    Vmid = (Vmin + Vmax) / 2;
                    Fmax = Fmid;
                    Fmid = GBlackScholes.BS_Price(cp, S, K, r, b, Vmid, T) - wrr;
                }
                else
                {
                    if (Fmax * Fmid < 0)
                    {
                        Vmin = Vmid;
                        Vmid = (Vmin + Vmax) / 2;
                        Fmin = Fmid;
                        Fmid = GBlackScholes.BS_Price(cp, S, K, r, b, Vmid, T) - wrr;
                    }
                    else
                        return Vmax;
                }
            }
            while (Vmax - Vmin >= accuracy);

            Vmid = (Vmin + Vmax) / 2.0;
            if (Vmid > 9)
                Vmid = 0;
            return Vmid;
        }

        /// <summary>
        /// BS_Price
        /// </summary>
        protected static double BS_Price(int cp, double S, double K, double r, double b, double v, double T)
        {
            //b = div
            double d1 = (Math.Log(S / K) + (r - b) + 0.5 * v * v * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double price = _cp * (S * Math.Exp(-b * T) * CN(_cp * d1) - K * Math.Exp(-r * T) * CN(_cp * d2));
            return price;
        }

        /// <summary>
        /// BS_Theta
        /// </summary>
        protected static double BS_Theta(int cp, double S, double K, double r, double b, double v, double T)
        {
            double d1 = (Math.Log(S / K) + (r - b) + 0.5 * v * v * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double theta = -1.0 * Math.Exp(-b * T) * S * v * N(d1) / (2.0 * Math.Sqrt(T)) + _cp * r * S * Math.Exp(-r * T) * CN(_cp * d1) - _cp * r * K * Math.Exp(-r * T) * CN(_cp * d2);
            return theta;
        }

        /// <summary>
        /// BS_Vega
        /// </summary>
        protected static double BS_Vega(int cp, double S, double K, double r, double b, double v, double T)
        {
            double d1 = (Math.Log(S / K) + (r - b) + 0.5 * v * v * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double vega = Math.Exp(-b * T) * S * N(d1) * Math.Sqrt(T);
            return vega;
        }
    }  //Generalized BlackScholes Model with Model Price, and Greeks

    public class Black76 : GBlackScholes  //Black76 Model with Model Price, and Greeks
    {
        /// <summary>
        /// Black76_Delta
        /// </summary>
        public static double Black76_Delta(int cp, double F, double K, double r, double v, double T)
        {
            double d1 = (Math.Log(F / K) + 0.5 * v * v * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double delta = _cp * Math.Exp(-r * T) * CN(_cp * d1);
            return delta;
        }

        /// <summary>
        /// Black76_Gamma
        /// </summary>
        public static double Black76_Gamma(int cp, double F, double K, double r, double v, double T)  
        {
            double d1 = (Math.Log(F / K) + 0.5 * v * v * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double gamma = Math.Exp(-r * T) * N(d1) / (F * v * Math.Sqrt(T));
            return gamma;
        }

        /// <summary>
        /// Black76_Rho
        /// </summary>
        public static double Black76_Rho(int cp, double F, double K, double r, double v, double T)
        {
            double d1 = (Math.Log(F / K) + 0.5 * v * v * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double rho = _cp * (K * T * Math.Exp(-r * T) * N(_cp * d2));
            return rho;
        }

        /// <summary>
        /// Black76_Price
        /// </summary>
        public static double Black76_Price(int cp, double F, double K, double r, double v, double T)
        {
            double d1 = (Math.Log(F / K) + 0.5 * v * v * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double price = _cp * Math.Exp(-r * T) * (F * CN(_cp * d1) - K * CN(_cp * d2));
            return price;
        }

        /// <summary>
        /// Black76_Theta
        /// </summary>
        public static double Black76_Theta(int cp, double F, double K, double r, double v, double T)
        {
            double d1 = (Math.Log(F / K) + 0.5 * v * v * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double theta = -1.0 * Math.Exp(-r * T) * F * v * N(d1) / (2.0 * Math.Sqrt(T)) + _cp * r * F * Math.Exp(-r * T) * CN(_cp * d1) - _cp * r * K * Math.Exp(-r * T) * CN(_cp * d2);
            return theta;
        }

        /// <summary>
        /// Black76_Vega
        /// </summary>
        public static double Black76_Vega(int cp, double F, double K, double r, double v, double T)
        {
            double d1 = (Math.Log(F / K) + 0.5 * v * v * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double vega = Math.Exp(-r * T) * F * N(d1) * Math.Sqrt(T);
            return vega;
        }

        /// <summary>
        /// Black76_ImpVol
        /// </summary>
        public static double Black76_ImpVol(double wrr, double accuracy, int cp, double F, double K, double r, double T)
        {
            if (F <= 0.0 || K <= 0.0 || T <= 0.0 || r < 0 || wrr.Equals(Double.NaN) || wrr <= 0.0 || accuracy <= 0)
                return 99.9;

            double Vmin = 0.01, Vmax = 2, Vmid = (Vmin + Vmax) / 2;
            double Fmin = Black76_Price(cp, F, K, r, Vmin, T) - wrr;
            double Fmax = Black76_Price(cp, F, K, r, Vmax, T) - wrr;
            double Fmid = Black76_Price(cp, F, K, r, Vmid, T) - wrr;

            do
            {
                if (Fmin * Fmid < 0)
                {
                    Vmax = Vmid;
                    Vmid = (Vmin + Vmax) / 2;
                    Fmax = Fmid;
                    Fmid = Black76_Price(cp, F, K, r, Vmid, T) - wrr;
                }
                else
                {
                    if (Fmax * Fmid < 0)
                    {
                        Vmin = Vmid;
                        Vmid = (Vmin + Vmax) / 2;
                        Fmin = Fmid;
                        Fmid = Black76_Price(cp, F, K, r, Vmid, T) - wrr;
                    }
                    else
                        return Vmax;
                }
            }
            while (Vmax - Vmin >= accuracy);

            Vmid = (Vmin + Vmax) / 2.0;
            if (Vmid > 9)
                Vmid = 0;
            return Vmid;
        }


    }
}
