﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
using System.Windows.Forms;
using PricingModel;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            int _cp = 1;  //1:call; -1: put
                          //double F = 100.0;
                          ////double K = 105.0;
                          //double r = 0.02;
                          //double HV = 0.3;
                          //double T = 0.5;
                          //double wrr = 4.7*0.2;
                          //double CR = 0.2;
                          //double accuracy = 0.00001;

            double F = 10780.0;
            //double K = 105.0;
            double r = 0.00255;
            double HV = 0.156303493994347;
            double T = 0.232876;
            double wrr = 4.7 * 0.2;
            double CR = 0.005;
            double accuracy = 0.00001;

            double[] K = { 10000, 10100, 10200, 10300, 10400, 10500, 10600, 10700, 10800, 10900, 11000 };
            
            textBox1.Text = "";
            //textBox1.Text = "Price = " + Black76.Black76_Price(_cp, F, K, r, HV, T).ToString("F20") + Environment.NewLine +
            //                "Delta = " + Black76.Black76_Delta(_cp, F, K, r, HV, T).ToString("F20") + Environment.NewLine +
            //                "Gamma = " + Black76.Black76_Gamma(_cp, F, K, r, HV, T).ToString("F20") + Environment.NewLine +
            //                "Vega = " + (Black76.Black76_Vega(_cp, F, K, r, HV, T) / 100).ToString("F20") + Environment.NewLine +
            //                "Theta = " + (Black76.Black76_Theta(_cp, F, K, r, HV, T) / 365).ToString("F20") + Environment.NewLine +
            //                "IV = " + (Black76.Black76_ImpVol(wrr/CR, accuracy, _cp, F, K, r, T) * 100).ToString("F20") + Environment.NewLine;

            for (int i = 0; i< K.Length; i++)
            {
                textBox1.Text = textBox1.Text + 
                "Stike = "+ K[i] + Environment.NewLine +
                "Price = " + (Black76.Black76_Price(_cp, F, K[i], r, HV, T)* CR).ToString("F20") + Environment.NewLine +
                "Delta = " + (Black76.Black76_Delta(_cp, F, K[i], r, HV, T)*CR).ToString("F20") + Environment.NewLine +
                "Gamma = " + (Black76.Black76_Gamma(_cp, F, K[i], r, HV, T)*CR).ToString("F20") + Environment.NewLine +
                "Vega = " + (Black76.Black76_Vega(_cp, F, K[i], r, HV, T)*CR/100).ToString("F20") + Environment.NewLine +
                "Theta = " + (Black76.Black76_Theta(_cp, F, K[i], r, HV, T)*CR/365).ToString("F20") + Environment.NewLine+
                "Rho = " + (Black76.Black76_Rho(_cp, F, K[i], r, HV, T) * CR/100).ToString("F20") + Environment.NewLine +
                Environment.NewLine;

            }


        }
    }
}
