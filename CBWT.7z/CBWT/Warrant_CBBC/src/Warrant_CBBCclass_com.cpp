#include "Warrant_CBBCclass_com.hpp"


CWarrant_CBBCclass::CWarrant_CBBCclass()
{
  g_pModule->InitializeComponentInstance(&m_hinst);
}
CWarrant_CBBCclass::~CWarrant_CBBCclass()
{
  if (m_hinst)
    g_pModule->TerminateInstance(&m_hinst);
}

HRESULT __stdcall CWarrant_CBBCclass::Warrant_CBBC(/* [in] */ long nargout,
                                                   /* [in,out] */ VARIANT* price,
                                                   /* [in,out] */ VARIANT* delta,
                                                   /* [in,out] */ VARIANT* gamma,
                                                   /* [in,out] */ VARIANT* vega,
                                                   /* [in] */ VARIANT S,
                                                   /* [in] */ VARIANT K,
                                                   /* [in] */ VARIANT H,
                                                   /* [in] */ VARIANT r,
                                                   /* [in] */ VARIANT T,
                                                   /* [in] */ VARIANT vol,
                                                   /* [in] */ VARIANT ER,
                                                   /* [in] */ VARIANT CP,
                                                   /* [in] */ VARIANT hit) {
  return( CallComFcn( "Warrant_CBBC", (int) nargout, 4, 9, price, delta, gamma,
                      vega, &S, &K, &H, &r, &T, &vol, &ER, &CP, &hit ) );
}


HRESULT __stdcall CWarrant_CBBCclass::MCRWaitForFigures()
{
  mclWaitForFiguresToDie(m_hinst);
  return(S_OK);
}

