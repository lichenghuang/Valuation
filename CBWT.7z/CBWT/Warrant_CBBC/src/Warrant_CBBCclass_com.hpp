#ifndef _Warrant_CBBC_Warrant_CBBCclass_com_HPP
#define _Warrant_CBBC_com_HPP 1

#include <windows.h>
#include "Warrant_CBBC_idl.h"
#include "mclmcrrt.h"
#include "mclcom.h"
#include "mclcommain.h"
#include "mclcomclass.h"

class CWarrant_CBBCclass : public CMCLClassImpl<IWarrant_CBBCclass,
                                                &IID_IWarrant_CBBCclass,
                                                CWarrant_CBBCclass,
                                                &CLSID_Warrant_CBBCclass>
{
public:
  CWarrant_CBBCclass();
  ~CWarrant_CBBCclass();

  HRESULT __stdcall Warrant_CBBC(/* [in] */ long nargout,
                                 /* [in,out] */ VARIANT* price,
                                 /* [in,out] */ VARIANT* delta,
                                 /* [in,out] */ VARIANT* gamma,
                                 /* [in,out] */ VARIANT* vega,
                                 /* [in] */ VARIANT S, /* [in] */ VARIANT K,
                                 /* [in] */ VARIANT H, /* [in] */ VARIANT r,
                                 /* [in] */ VARIANT T, /* [in] */ VARIANT vol,
                                 /* [in] */ VARIANT ER, /* [in] */ VARIANT CP,
                                 /* [in] */ VARIANT hit);
  

  HRESULT __stdcall MCRWaitForFigures();
  
};
#endif
