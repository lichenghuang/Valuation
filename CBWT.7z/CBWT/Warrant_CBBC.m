% Warrant_CBBC (������,����v�ҳ���)
function [price delta gamma vega]=Warrant_CBBC(S,K,H,r,T,vol,ER,CP,hit)
% ----------------------------------------------------------------------
% S     �G�s���Ъ��ثe���ѻ�
% K     �G�i����
% H     �G�ɭ���
% r     �G�~�ƵL���I�Q�v
% T     �G�Ѿl�Ѽ�
% vol   �G�~�Ƴs���Ъ��i�ʲv
% ER    �G��Ϥ��
% CP    �GC(�R�v)/P(���v)
% hit   �G���IĲ��ɭ���hit=1,�_�hhit=0.
% ----------------------------------------------------------------------

price=0; delta=0; gamma=0; vega=0;

dt=1/365;
N=20000;
if ((CP=='C')*(S<=H)+(CP=='P')*(S>=H)+hit)>0
    hit=1;
else
    hit=0;
end

if T==0
    price=ER*max((S-K)*(CP=='C')+(K-S)*(CP=='P'),0);
else
    seed=311;
    randn('state', seed);
    days=T*(hit==0)+(hit==1);
    temp=randn(N,days);
    temp1=repmat([1:days],[N,1]);
    ST=S*exp((r-0.5*vol^2)*temp1*dt+vol*sqrt(dt)*cumsum(temp,2));
    tau=cumsum(((CP=='C')*cumsum(cumsum(ST<=H,2),2)+(CP=='P')*cumsum(cumsum(ST>=H,2),2))>0,2);
    payoff=sum((tau==2).*max((ST-K)*(CP=='C')+(K-ST)*(CP=='P'),0),2)+((sum(tau,2)==0)+(tau(:,end)==1)).*max((ST(:,end)-K)*(CP=='C')+(K-ST(:,end))*(CP=='P'),0);
    discount=exp(-r*dt*(sum(temp1.*(tau==2),2)+temp1(:,end).*(tau(:,end)==0)));
    price=ER*mean(discount.*payoff);
    
    error=0.0001;
    
    ST_u=(S+error)*exp((r-0.5*vol^2)*temp1*dt+vol*sqrt(dt)*cumsum(temp,2));
    tau_u=tau;
    payoff_u=sum((tau_u==2).*max((ST_u-K)*(CP=='C')+(K-ST_u)*(CP=='P'),0),2)+((sum(tau_u,2)==0)+(tau_u(:,end)==1)).*max((ST_u(:,end)-K)*(CP=='C')+(K-ST_u(:,end))*(CP=='P'),0);
    discount_u=exp(-r*dt*(sum(temp1.*(tau_u==2),2)+temp1(:,end).*(tau_u(:,end)==0)));
    price_u=ER*mean(discount_u.*payoff_u);
    
    ST_d=(S-error)*exp((r-0.5*vol^2)*temp1*dt+vol*sqrt(dt)*cumsum(temp,2));
    tau_d=tau;
    payoff_d=sum((tau_d==2).*max((ST_d-K)*(CP=='C')+(K-ST_d)*(CP=='P'),0),2)+((sum(tau_d,2)==0)+(tau_d(:,end)==1)).*max((ST_d(:,end)-K)*(CP=='C')+(K-ST_d(:,end))*(CP=='P'),0);
    discount_d=exp(-r*dt*(sum(temp1.*(tau_d==2),2)+temp1(:,end).*(tau_d(:,end)==0)));
    price_d=ER*mean(discount_d.*payoff_d);
    
    ST_vu=S*exp((r-0.5*(vol+error)^2)*temp1*dt+(vol+error)*sqrt(dt)*cumsum(temp,2));
    tau_vu=tau;
    payoff_vu=sum((tau_vu==2).*max((ST_vu-K)*(CP=='C')+(K-ST_vu)*(CP=='P'),0),2)+((sum(tau_vu,2)==0)+(tau_vu(:,end)==1)).*max((ST_vu(:,end)-K)*(CP=='C')+(K-ST_vu(:,end))*(CP=='P'),0);
    discount_vu=exp(-r*dt*(sum(temp1.*(tau_vu==2),2)+temp1(:,end).*(tau_vu(:,end)==0)));
    price_vu=ER*mean(discount_vu.*payoff_vu);
    
    ST_vd=S*exp((r-0.5*(vol-error)^2)*temp1*dt+(vol-error)*sqrt(dt)*cumsum(temp,2));
    tau_vd=tau;
    payoff_vd=sum((tau_vd==2).*max((ST_vd-K)*(CP=='C')+(K-ST_vd)*(CP=='P'),0),2)+((sum(tau_vd,2)==0)+(tau_vd(:,end)==1)).*max((ST_vd(:,end)-K)*(CP=='C')+(K-ST_vd(:,end))*(CP=='P'),0);
    discount_vd=exp(-r*dt*(sum(temp1.*(tau_vd==2),2)+temp1(:,end).*(tau_vd(:,end)==0)));
    price_vd=ER*mean(discount_vd.*payoff_vd);
    
    delta=(price_u-price_d)/(error*2);
    gamma=(price_u-2*price+price_d)/(error^2);
    vega=(price_vu-price_vd)/(error*2);
end