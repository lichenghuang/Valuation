﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
//using System.Linq;
using System.Text;
using System.Windows.Forms;
//using PricingModel;  //Black76, FXBlackScholes
using CommodityBlackScholes;
using FXBlackScholes;
using RangeAccrual;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void button1_Click(object sender, EventArgs e)  //黃金選擇權
        {
            int _cp = -1;  //1:call; -1: put
                           //double F = 100.0;
                           ////double K = 105.0;
                           //double r = 0.02;
                           //double HV = 0.3;
                           //double T = 0.5;
                           //double wrr = 4.7*0.2;
                           //double CR = 0.2;
                           //double accuracy = 0.00001;
          
            double F = 26.74;
            //double K = 105.0;
            double r = 0.0053878;
            double rf = 0.0053878;
            double HV = 0.507294856981725;
            //double T = 0.0520547945205479;
            double T = 0;
            double wrr = 4.7 * 0.2;
            double CR = 0.5;
            double accuracy = 0.00001;
            
            double[] K = { 26  };

            //期貨選擇權評價
            textBox1.Text = "";
            //textBox1.Text = "Price = " + Black76.Black76_Price(_cp, F, K, r, HV, T).ToString("F20") + Environment.NewLine +
            //                "Delta = " + Black76.Black76_Delta(_cp, F, K, r, HV, T).ToString("F20") + Environment.NewLine +
            //                "Gamma = " + Black76.Black76_Gamma(_cp, F, K, r, HV, T).ToString("F20") + Environment.NewLine +
            //                "Vega = " + (Black76.Black76_Vega(_cp, F, K, r, HV, T) / 100).ToString("F20") + Environment.NewLine +
            //                "Theta = " + (Black76.Black76_Theta(_cp, F, K, r, HV, T) / 365).ToString("F20") + Environment.NewLine +
            //                "IV = " + (Black76.Black76_ImpVol(wrr/CR, accuracy, _cp, F, K, r, T) * 100).ToString("F20") + Environment.NewLine;
           
            for (int i = 0; i< K.Length; i++)
            {
                //匯率類評價
                //textBox1.Text = textBox1.Text + 
                //"Stike = "+ K[i] + Environment.NewLine +
                //"Price = " + (FXBlackScholes.FXBS_Price(_cp, F, K[i], r, rf, HV, T)* CR).ToString("F20") + Environment.NewLine +
                //"Delta = " + (FXBlackScholes.FXBS_Delta(_cp, F, K[i], r, rf, HV, T)*CR).ToString("F20") + Environment.NewLine +
                //"Gamma = " + (FXBlackScholes.FXBS_Gamma(_cp, F, K[i], r, rf, HV, T)*CR).ToString("F20") + Environment.NewLine +
                //"Vega = " + (FXBlackScholes.FXBS_Vega(_cp, F, K[i], r, rf, HV, T)*CR / 100).ToString("F20") + Environment.NewLine +
                //"Theta = " + (FXBlackScholes.FXBS_Theta(_cp, F, K[i], r, rf, HV, T)*CR / 365).ToString("F20") + Environment.NewLine+
                //Environment.NewLine;

                //商品類評價
                //textBox1.Text = textBox1.Text +
                //"Stike = " + K[i] + Environment.NewLine +
                //"Price = " + (CommodityBlackScholes.CommodityBS_Price(_cp, F, K[i], r, HV, T) * CR).ToString("F20") + Environment.NewLine +
                //"Delta = " + (CommodityBlackScholes.CommodityBS_Delta(_cp, F, K[i], r, HV, T) * CR).ToString("F20") + Environment.NewLine +
                //"Gamma = " + (CommodityBlackScholes.CommodityBS_Gamma(_cp, F, K[i], r, HV, T) * CR).ToString("F20") + Environment.NewLine +
                //"Vega = " + (CommodityBlackScholes.CommodityBS_Vega(_cp, F, K[i], r, HV, T) * CR / 100).ToString("F20") + Environment.NewLine +
                //"Theta = " + (CommodityBlackScholes.CommodityBS_Theta(_cp, F, K[i], r, HV, T) * CR / 365).ToString("F20") + Environment.NewLine +
                //Environment.NewLine;
                
                //商品類評價
                textBox1.Text = textBox1.Text +
                "Stike = " + K[i] + Environment.NewLine +
                "Price = " + (CommodityBS.CommodityBS_Price(_cp, F, K[i], r, HV, T) * CR).ToString("F20") + Environment.NewLine +
                "Delta = " + (CommodityBS.CommodityBS_Delta(_cp, F, K[i], r, HV, T) * CR).ToString("F20") + Environment.NewLine +
                "Gamma = " + (CommodityBS.CommodityBS_Gamma(_cp, F, K[i], r, HV, T) * CR).ToString("F20") + Environment.NewLine +
                "Vega = " + (CommodityBS.CommodityBS_Vega(_cp, F, K[i], r, HV, T) * CR / 100).ToString("F20") + Environment.NewLine +
                "Theta = " + (CommodityBS.CommodityBS_Theta(_cp, F, K[i], r, HV, T) * CR / 365).ToString("F20") + Environment.NewLine +
                Environment.NewLine;


         
            }


        }

        private void button2_Click(object sender, EventArgs e)  //人民幣選擇權
        {
            int _cp = -1;  //1:call; -1: put
                           //double F = 100.0;
                           ////double K = 105.0;
                           //double r = 0.02;
                           //double HV = 0.3;
                           //double T = 0.5;
                           //double wrr = 4.7*0.2;
                           //double CR = 0.2;
                           //double accuracy = 0.00001;

            double F = 6.9425;
            //double K = 105.0;
            double r = 0.99;
            double rf = 0.02865;
            double HV = 0.059693294673296;
            //double T = 0.153424657534247;
            double T = 0;
            double wrr = 4.7 * 0.2;
            double CR = 1.0;
            double accuracy = 0.00001;

            double[] K = { 5.74, 5.82, 5.9, 5.96 };

            //期貨選擇權評價
            textBox1.Text = "";
            //textBox1.Text = "Price = " + Black76.Black76_Price(_cp, F, K, r, HV, T).ToString("F20") + Environment.NewLine +
            //                "Delta = " + Black76.Black76_Delta(_cp, F, K, r, HV, T).ToString("F20") + Environment.NewLine +
            //                "Gamma = " + Black76.Black76_Gamma(_cp, F, K, r, HV, T).ToString("F20") + Environment.NewLine +
            //                "Vega = " + (Black76.Black76_Vega(_cp, F, K, r, HV, T) / 100).ToString("F20") + Environment.NewLine +
            //                "Theta = " + (Black76.Black76_Theta(_cp, F, K, r, HV, T) / 365).ToString("F20") + Environment.NewLine +
            //                "IV = " + (Black76.Black76_ImpVol(wrr/CR, accuracy, _cp, F, K, r, T) * 100).ToString("F20") + Environment.NewLine;

            for (int i = 0; i < K.Length; i++)
            {
                //匯率類評價
                textBox1.Text = textBox1.Text +
                "Stike = " + K[i] + Environment.NewLine +
                "Price = " + (FXBS.FXBS_Price(_cp, F, K[i], r, rf, HV, T) * CR).ToString("F20") + Environment.NewLine +
                "Delta = " + (FXBS.FXBS_Delta(_cp, F, K[i], r, rf, HV, T) * CR).ToString("F20") + Environment.NewLine +
                "Gamma = " + (FXBS.FXBS_Gamma(_cp, F, K[i], r, rf, HV, T) * CR).ToString("F20") + Environment.NewLine +
                "Vega = " + (FXBS.FXBS_Vega(_cp, F, K[i], r, rf, HV, T) * CR / 100).ToString("F20") + Environment.NewLine +
                "Theta = " + (FXBS.FXBS_Theta(_cp, F, K[i], r, rf, HV, T) * CR / 365).ToString("F20") + Environment.NewLine +
                Environment.NewLine;

            }
        }

        //RangeAccrual
        private void button3_Click(object sender, EventArgs e)
        {
            double spotPrice = 1;
            //int no_day = 5;
            int N = 5;
            double CouponRate = 0.035;
            double digitalSpread = spotPrice * 0.005;
            double discountRate = 0.03;
            double atmVolatility = 0.3;
            double Drift = 0;
            double[] dividends = new double[N + 1];
            double[] hisPrices = new double[N + 1];


            DateTime valueDate = new DateTime(2016, 03, 11);
            double valueDate_d = Convert.ToDouble(valueDate.ToOADate());

            DateTime[] TradingDate = new DateTime[N + 1];
            TradingDate[0] = new DateTime(2016, 03, 11);
            TradingDate[1] = new DateTime(2016, 03, 14);
            TradingDate[2] = new DateTime(2016, 03, 15);
            TradingDate[3] = new DateTime(2016, 03, 16);
            TradingDate[4] = new DateTime(2016, 03, 17);
            TradingDate[5] = new DateTime(2016, 03, 18);

            double[] TradingDate_d = new double[N + 1];
            double[] upperBound = new double[N + 1];
            double[] lowerBound = new double[N + 1];

            for (int i = 0; i < N + 1; i++)
            {
                TradingDate_d[i] = Convert.ToDouble(TradingDate[i].ToOADate());
                upperBound[i] = 10;
                lowerBound[i] = 1;
                dividends[i] = 0;
                hisPrices[i] = 0;
            }

            double RA_price = 0;
            double RA_delta = 0;
            double RA_gamma = 0;
            double RA_vega = 0;
            double RA_theta = 0;

            RA_price = RangeAccrualModel.RangeAccrualPrice(valueDate_d, upperBound, lowerBound, CouponRate, digitalSpread, spotPrice, discountRate, atmVolatility, Drift, N, TradingDate_d, dividends, hisPrices);
            RA_delta = RangeAccrualModel.RangeAccrualDelta(valueDate_d, upperBound, lowerBound, CouponRate, digitalSpread, spotPrice, discountRate, atmVolatility, Drift, N, TradingDate_d, dividends, hisPrices);
            RA_gamma = RangeAccrualModel.RangeAccrualGamma(valueDate_d, upperBound, lowerBound, CouponRate, digitalSpread, spotPrice, discountRate, atmVolatility, Drift, N, TradingDate_d, dividends, hisPrices);
            RA_vega = RangeAccrualModel.RangeAccrualVega(valueDate_d, upperBound, lowerBound, CouponRate, digitalSpread, spotPrice, discountRate, atmVolatility, Drift, N, TradingDate_d, dividends, hisPrices);
            RA_theta = RangeAccrualModel.RangeAccrualOneDayTheta(valueDate_d, upperBound, lowerBound, CouponRate, digitalSpread, spotPrice, discountRate, atmVolatility, Drift, N, TradingDate_d, dividends, hisPrices);

            textBox1.Text = textBox1.Text +
            "price = " + RA_price.ToString() + Environment.NewLine +
            "delta = " + RA_delta.ToString() + Environment.NewLine +
            "gamma = " + RA_gamma.ToString() + Environment.NewLine +
            "vega = " + RA_vega.ToString() + Environment.NewLine +
            "theta = " + RA_theta.ToString() + Environment.NewLine;

        }

        //CBBC_ELN
        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
