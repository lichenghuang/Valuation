﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CommodityBlackScholes
{
    public class CommodityBS
    {
        /// <summary>
        /// CDF of Normal Distribution
        /// </summary>
        protected static double CN(double X)
        {
            double L = 0.0;
            double K = 0.0;
            double a1 = 0.31938153;
            double a2 = -0.356563782;
            double a3 = 1.781477937;
            double a4 = -1.821255978;
            double a5 = 1.330274429;
            double val = 0.0;
            double Pi = 3.141592653;
            L = Math.Abs(X);
            K = 1 / (1 + 0.2316419 * L);
            val = 1.0 - (1.0 / Math.Sqrt(2 * Pi)) * Math.Exp(-L * L / 2.0) * (a1 * K + a2 * K * K + a3 * K * K * K + a4 * K * K * K * K + a5 * K * K * K * K * K);

            if (X < 0.0)
                val = 1.0 - val;

            return val;
        }
        /// <summary>
        /// PDF of Normal Distribution
        /// </summary>
        protected static double N(double X)
        {
            double Pi = 3.141592653;
            double val = Math.Exp(-X * X / 2.0) / Math.Sqrt(2.0 * Pi);
            return val;
        }
        /// <summary>
        /// CommodityBS_Delta
        /// </summary>
        public static double CommodityBS_Delta(int cp, double S, double K, double r, double v, double T)
        {
            double q = 0;
            double d1 = (Math.Log(S / K) + ((r - q) + 0.5 * v * v) * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double delta = _cp * Math.Exp(-q * T) * CN(_cp * d1);
            return delta;
        }

        /// <summary>
        /// CommodityBS_Gamma
        /// </summary>
        public static double CommodityBS_Gamma(int cp, double S, double K, double r, double v, double T)
        {
            double q = 0;
            double d1 = (Math.Log(S / K) + ((r - q) + 0.5 * v * v) * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double gamma = Math.Exp(-q * T) * N(d1) / (S * v * Math.Sqrt(T));
            return gamma;
        }

        /// <summary>
        /// CommodityBS_ImpVol
        /// </summary>
        public static double CommodityBS_ImpVol(double wrr, double accuracy, int cp, double S, double K, double r, double v, double T)
        {
            if (S <= 0.0 || K <= 0.0 || T <= 0.0 || r < 0 || wrr.Equals(Double.NaN) || wrr <= 0.0 || accuracy <= 0)
                return 99.9;

            double q = 0;
            double Vmin = 0.01, Vmax = 2, Vmid = (Vmin + Vmax) / 2;
            double Fmin = CommodityBS_Price(cp, S, K, r, Vmin, T) - wrr;
            double Fmax = CommodityBS_Price(cp, S, K, r, Vmax, T) - wrr;
            double Fmid = CommodityBS_Price(cp, S, K, r, Vmid, T) - wrr;

            do
            {
                if (Fmin * Fmid < 0)
                {
                    Vmax = Vmid;
                    Vmid = (Vmin + Vmax) / 2;
                    Fmax = Fmid;
                    Fmid = CommodityBS_Price(cp, S, K, r, Vmid, T) - wrr;
                }
                else
                {
                    if (Fmax * Fmid < 0)
                    {
                        Vmin = Vmid;
                        Vmid = (Vmin + Vmax) / 2;
                        Fmin = Fmid;
                        Fmid = CommodityBS_Price(cp, S, K, r, Vmid, T) - wrr;
                    }
                    else
                        return Vmax;
                }
            }
            while (Vmax - Vmin >= accuracy);

            Vmid = (Vmin + Vmax) / 2.0;
            if (Vmid > 9)
                Vmid = 0;
            return Vmid;
        }

        /// <summary>
        /// CommodityBS_Price
        /// </summary>
        public static double CommodityBS_Price(int cp, double S, double K, double r, double v, double T)
        {
            double q = 0;
            double d1 = (Math.Log(S / K) + ((r - q) + 0.5 * v * v) * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            //double price = _cp * Math.Exp(-b * T) * (S * CN(_cp * d1) - K * CN(_cp * d2));
            double price = _cp * (S * Math.Exp(-q * T) * CN(_cp * d1) - K * Math.Exp(-r * T) * CN(_cp * d2));
            return price;
        }

        /// <summary>
        /// CommodityBS_Theta
        /// </summary>
        public static double CommodityBS_Theta(int cp, double S, double K, double r, double v, double T)
        {
            double q = 0;
            double d1 = (Math.Log(S / K) + ((r - q) + 0.5 * v * v) * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double theta = -1.0 * Math.Exp(-q * T) * S * v * N(d1) / (2.0 * Math.Sqrt(T)) + _cp * q * S * Math.Exp(-q * T) * CN(_cp * d1) - _cp * r * K * Math.Exp(-r * T) * CN(_cp * d2);
            return theta;
        }

        /// <summary>
        /// CommodityBS_Vega
        /// </summary>
        public static double CommodityBS_Vega(int cp, double S, double K, double r, double v, double T)
        {
            double q = 0;
            double d1 = (Math.Log(S / K) + ((r - q) + 0.5 * v * v) * T) / (v * Math.Sqrt(T));
            double d2 = d1 - v * Math.Sqrt(T);
            double _cp = Convert.ToDouble(cp);
            double vega = Math.Exp(-q * T) * S * N(d1) * Math.Sqrt(T);
            return vega;
        }
    }  //Generalized BlackScholes Model with Model Price, and Greeks
}

