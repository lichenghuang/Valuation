﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarrantAssistant
{
    public partial class FrmTempCredit : Form
    {
        DataTable dt;
        public FrmTempCredit()
        {
            InitializeComponent();
        }

        private void FrmTempCredit_Load(object sender, EventArgs e)
        {
            LoadData();
            //InitialGrid();
            ultraGrid1.Select();
        }
        private void LoadData()
        {
            string sql = $@"SELECT  [UID], [UName], [Market], [AvailableShares], [IssuedPercent]
                        FROM [newEDIS].[dbo].[NextQuarterCredit]";
            dt = EDLib.SQL.MSSQL.ExecSqlQry(sql, GlobalVar.loginSet.newEDIS);
            ultraGrid1.DataSource = dt;
        }
        private void LoadByUid()
        {
            string sql2 = $@"SELECT  [UID], [UName], [Market], [AvailableShares], [IssuedPercent]
                        FROM [newEDIS].[dbo].[NextQuarterCredit]
                        WHERE [UID]='{textBox1.Text}'";
            DataTable dt2 = EDLib.SQL.MSSQL.ExecSqlQry(sql2, GlobalVar.loginSet.newEDIS);
            if (dt2.Rows.Count > 0)
                ultraGrid1.DataSource = dt2;
            else
            {
                MessageBox.Show("無此標的");
                LoadData();
            }
        }
        private void InitialGrid()
        {
            
        }
        private void TextBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter && textBox1.Text != "")
            {
                LoadByUid();
                //toolStripComboBox1.Text = "";
            }
            else if (e.KeyCode == Keys.Enter && textBox1.Text == "")
                LoadData();
        }
    }
}
