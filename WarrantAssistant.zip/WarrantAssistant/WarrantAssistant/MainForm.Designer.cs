﻿namespace WarrantAssistant
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置 Managed 資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器
        /// 修改這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.查詢及訊息ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.標的SummaryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.特殊標的ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.標的發行檢查ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.put發行檢查ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.已發行權證ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.可增額列表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.建議VolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.到期釋出額度ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.發行增額總表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.搶額度總表含增額ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.發行總表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.增額總表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.traderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.已發權證條件發行ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.發行條件輸入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.增額條件輸入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.代理人發行條件輸入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.代理人增額條件輸入ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.發行參數設定ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.原始參數查詢ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.發行篩選ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.發行矩陣設定ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.行政ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.可增額列表ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.試算表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.修正權證名稱ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.轉申請發行TXTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.自動申請發行TXTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.權證系統上傳檔ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.增額上傳檔ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.關係人列表ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.修改檔案名稱ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.財工ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.詳細LOGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripComboBox1 = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.ultraGrid2 = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.ultraGrid1 = new Infragistics.Win.UltraWinGrid.UltraGrid();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.label1 = new System.Windows.Forms.Label();
            this.非本季標的額度預估ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGrid2)).BeginInit();
            this.toolStrip1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // 查詢及訊息ToolStripMenuItem
            // 
            this.查詢及訊息ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.標的SummaryToolStripMenuItem,
            this.特殊標的ToolStripMenuItem,
            this.標的發行檢查ToolStripMenuItem,
            this.put發行檢查ToolStripMenuItem,
            this.已發行權證ToolStripMenuItem,
            this.可增額列表ToolStripMenuItem,
            this.建議VolToolStripMenuItem,
            this.到期釋出額度ToolStripMenuItem,
            this.非本季標的額度預估ToolStripMenuItem});
            this.查詢及訊息ToolStripMenuItem.Name = "查詢及訊息ToolStripMenuItem";
            this.查詢及訊息ToolStripMenuItem.Size = new System.Drawing.Size(72, 24);
            this.查詢及訊息ToolStripMenuItem.Text = "基本資料";
            // 
            // 標的SummaryToolStripMenuItem
            // 
            this.標的SummaryToolStripMenuItem.Name = "標的SummaryToolStripMenuItem";
            this.標的SummaryToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.標的SummaryToolStripMenuItem.Text = "標的Summary";
            this.標的SummaryToolStripMenuItem.Click += new System.EventHandler(this.標的SummaryToolStripMenuItem_Click);
            // 
            // 特殊標的ToolStripMenuItem
            // 
            this.特殊標的ToolStripMenuItem.Name = "特殊標的ToolStripMenuItem";
            this.特殊標的ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.特殊標的ToolStripMenuItem.Text = "特殊標的";
            this.特殊標的ToolStripMenuItem.Click += new System.EventHandler(this.特殊標的ToolStripMenuItem_Click);
            // 
            // 標的發行檢查ToolStripMenuItem
            // 
            this.標的發行檢查ToolStripMenuItem.Name = "標的發行檢查ToolStripMenuItem";
            this.標的發行檢查ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.標的發行檢查ToolStripMenuItem.Text = "標的發行檢查";
            this.標的發行檢查ToolStripMenuItem.Click += new System.EventHandler(this.標的發行檢查ToolStripMenuItem_Click);
            // 
            // put發行檢查ToolStripMenuItem
            // 
            this.put發行檢查ToolStripMenuItem.Name = "put發行檢查ToolStripMenuItem";
            this.put發行檢查ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.put發行檢查ToolStripMenuItem.Text = "Put發行檢查";
            this.put發行檢查ToolStripMenuItem.Click += new System.EventHandler(this.put發行檢查ToolStripMenuItem_Click);
            // 
            // 已發行權證ToolStripMenuItem
            // 
            this.已發行權證ToolStripMenuItem.Name = "已發行權證ToolStripMenuItem";
            this.已發行權證ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.已發行權證ToolStripMenuItem.Text = "已發行權證";
            this.已發行權證ToolStripMenuItem.Click += new System.EventHandler(this.已發行權證ToolStripMenuItem_Click);
            // 
            // 可增額列表ToolStripMenuItem
            // 
            this.可增額列表ToolStripMenuItem.Name = "可增額列表ToolStripMenuItem";
            this.可增額列表ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.可增額列表ToolStripMenuItem.Text = "可增額列表";
            this.可增額列表ToolStripMenuItem.Click += new System.EventHandler(this.可增額列表ToolStripMenuItem_Click);
            // 
            // 建議VolToolStripMenuItem
            // 
            this.建議VolToolStripMenuItem.Name = "建議VolToolStripMenuItem";
            this.建議VolToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.建議VolToolStripMenuItem.Text = "建議Vol";
            this.建議VolToolStripMenuItem.Click += new System.EventHandler(this.建議VolToolStripMenuItem_Click);
            // 
            // 到期釋出額度ToolStripMenuItem
            // 
            this.到期釋出額度ToolStripMenuItem.Name = "到期釋出額度ToolStripMenuItem";
            this.到期釋出額度ToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.到期釋出額度ToolStripMenuItem.Text = "到期釋出額度";
            this.到期釋出額度ToolStripMenuItem.Click += new System.EventHandler(this.到期釋出額度ToolStripMenuItem_Click);
            // 
            // 發行增額總表ToolStripMenuItem
            // 
            this.發行增額總表ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.搶額度總表含增額ToolStripMenuItem,
            this.發行總表ToolStripMenuItem,
            this.增額總表ToolStripMenuItem});
            this.發行增額總表ToolStripMenuItem.Name = "發行增額總表ToolStripMenuItem";
            this.發行增額總表ToolStripMenuItem.Size = new System.Drawing.Size(111, 24);
            this.發行增額總表ToolStripMenuItem.Text = "發行及增額總表";
            // 
            // 搶額度總表含增額ToolStripMenuItem
            // 
            this.搶額度總表含增額ToolStripMenuItem.Name = "搶額度總表含增額ToolStripMenuItem";
            this.搶額度總表含增額ToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.搶額度總表含增額ToolStripMenuItem.Text = "搶額度總表 (含增額)";
            this.搶額度總表含增額ToolStripMenuItem.Click += new System.EventHandler(this.搶額度總表含增額ToolStripMenuItem_Click);
            // 
            // 發行總表ToolStripMenuItem
            // 
            this.發行總表ToolStripMenuItem.Name = "發行總表ToolStripMenuItem";
            this.發行總表ToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.發行總表ToolStripMenuItem.Text = "發行總表";
            this.發行總表ToolStripMenuItem.Click += new System.EventHandler(this.發行總表ToolStripMenuItem_Click);
            // 
            // 增額總表ToolStripMenuItem
            // 
            this.增額總表ToolStripMenuItem.Name = "增額總表ToolStripMenuItem";
            this.增額總表ToolStripMenuItem.Size = new System.Drawing.Size(191, 22);
            this.增額總表ToolStripMenuItem.Text = "增額總表";
            this.增額總表ToolStripMenuItem.Click += new System.EventHandler(this.增額總表ToolStripMenuItem_Click);
            // 
            // traderToolStripMenuItem
            // 
            this.traderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.已發權證條件發行ToolStripMenuItem,
            this.發行條件輸入ToolStripMenuItem,
            this.增額條件輸入ToolStripMenuItem,
            this.代理人發行條件輸入ToolStripMenuItem,
            this.代理人增額條件輸入ToolStripMenuItem,
            this.發行參數設定ToolStripMenuItem,
            this.原始參數查詢ToolStripMenuItem,
            this.發行篩選ToolStripMenuItem,
            this.發行矩陣設定ToolStripMenuItem});
            this.traderToolStripMenuItem.Name = "traderToolStripMenuItem";
            this.traderToolStripMenuItem.Size = new System.Drawing.Size(59, 24);
            this.traderToolStripMenuItem.Text = "交易員";
            // 
            // 已發權證條件發行ToolStripMenuItem
            // 
            this.已發權證條件發行ToolStripMenuItem.Name = "已發權證條件發行ToolStripMenuItem";
            this.已發權證條件發行ToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.已發權證條件發行ToolStripMenuItem.Text = "已發權證條件發行";
            this.已發權證條件發行ToolStripMenuItem.Click += new System.EventHandler(this.已發權證條件發行ToolStripMenuItem_Click);
            // 
            // 發行條件輸入ToolStripMenuItem
            // 
            this.發行條件輸入ToolStripMenuItem.Name = "發行條件輸入ToolStripMenuItem";
            this.發行條件輸入ToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.發行條件輸入ToolStripMenuItem.Text = "發行條件輸入";
            this.發行條件輸入ToolStripMenuItem.Click += new System.EventHandler(this.發行條件輸入ToolStripMenuItem_Click);
            // 
            // 增額條件輸入ToolStripMenuItem
            // 
            this.增額條件輸入ToolStripMenuItem.Name = "增額條件輸入ToolStripMenuItem";
            this.增額條件輸入ToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.增額條件輸入ToolStripMenuItem.Text = "增額條件輸入";
            this.增額條件輸入ToolStripMenuItem.Click += new System.EventHandler(this.增額條件輸入ToolStripMenuItem_Click);
            // 
            // 代理人發行條件輸入ToolStripMenuItem
            // 
            this.代理人發行條件輸入ToolStripMenuItem.Name = "代理人發行條件輸入ToolStripMenuItem";
            this.代理人發行條件輸入ToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.代理人發行條件輸入ToolStripMenuItem.Text = "代理人-發行條件輸入";
            this.代理人發行條件輸入ToolStripMenuItem.Click += new System.EventHandler(this.代理人發行條件輸入ToolStripMenuItem_Click);
            // 
            // 代理人增額條件輸入ToolStripMenuItem
            // 
            this.代理人增額條件輸入ToolStripMenuItem.Name = "代理人增額條件輸入ToolStripMenuItem";
            this.代理人增額條件輸入ToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.代理人增額條件輸入ToolStripMenuItem.Text = "代理人-增額條件輸入";
            this.代理人增額條件輸入ToolStripMenuItem.Click += new System.EventHandler(this.代理人增額條件輸入ToolStripMenuItem_Click);
            // 
            // 發行參數設定ToolStripMenuItem
            // 
            this.發行參數設定ToolStripMenuItem.Name = "發行參數設定ToolStripMenuItem";
            this.發行參數設定ToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.發行參數設定ToolStripMenuItem.Text = "發行參數設定";
            this.發行參數設定ToolStripMenuItem.Click += new System.EventHandler(this.發行參數設定ToolStripMenuItem_Click);
            // 
            // 原始參數查詢ToolStripMenuItem
            // 
            this.原始參數查詢ToolStripMenuItem.Name = "原始參數查詢ToolStripMenuItem";
            this.原始參數查詢ToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.原始參數查詢ToolStripMenuItem.Text = "原始參數查詢";
            this.原始參數查詢ToolStripMenuItem.Click += new System.EventHandler(this.原始參數查詢ToolStripMenuItem_Click);
            // 
            // 發行篩選ToolStripMenuItem
            // 
            this.發行篩選ToolStripMenuItem.Name = "發行篩選ToolStripMenuItem";
            this.發行篩選ToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.發行篩選ToolStripMenuItem.Text = "發行篩選";
            this.發行篩選ToolStripMenuItem.Click += new System.EventHandler(this.發行篩選ToolStripMenuItem_Click);
            // 
            // 發行矩陣設定ToolStripMenuItem
            // 
            this.發行矩陣設定ToolStripMenuItem.Name = "發行矩陣設定ToolStripMenuItem";
            this.發行矩陣設定ToolStripMenuItem.Size = new System.Drawing.Size(199, 22);
            this.發行矩陣設定ToolStripMenuItem.Text = "發行矩陣設定";
            this.發行矩陣設定ToolStripMenuItem.Click += new System.EventHandler(this.發行矩陣設定ToolStripMenuItem_Click);
            // 
            // 行政ToolStripMenuItem
            // 
            this.行政ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.可增額列表ToolStripMenuItem1,
            this.試算表ToolStripMenuItem,
            this.toolStripSeparator1,
            this.修正權證名稱ToolStripMenuItem,
            this.轉申請發行TXTToolStripMenuItem,
            this.自動申請發行TXTToolStripMenuItem,
            this.權證系統上傳檔ToolStripMenuItem,
            this.增額上傳檔ToolStripMenuItem,
            this.關係人列表ToolStripMenuItem,
            this.修改檔案名稱ToolStripMenuItem});
            this.行政ToolStripMenuItem.Name = "行政ToolStripMenuItem";
            this.行政ToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.行政ToolStripMenuItem.Text = "行政";
            // 
            // 可增額列表ToolStripMenuItem1
            // 
            this.可增額列表ToolStripMenuItem1.Name = "可增額列表ToolStripMenuItem1";
            this.可增額列表ToolStripMenuItem1.Size = new System.Drawing.Size(176, 22);
            this.可增額列表ToolStripMenuItem1.Text = "可增額列表";
            this.可增額列表ToolStripMenuItem1.Click += new System.EventHandler(this.可增額列表ToolStripMenuItem1_Click);
            // 
            // 試算表ToolStripMenuItem
            // 
            this.試算表ToolStripMenuItem.Name = "試算表ToolStripMenuItem";
            this.試算表ToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.試算表ToolStripMenuItem.Text = "7-1試算表";
            this.試算表ToolStripMenuItem.Click += new System.EventHandler(this.試算表ToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(173, 6);
            // 
            // 修正權證名稱ToolStripMenuItem
            // 
            this.修正權證名稱ToolStripMenuItem.Name = "修正權證名稱ToolStripMenuItem";
            this.修正權證名稱ToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.修正權證名稱ToolStripMenuItem.Text = "修正權證名稱";
            this.修正權證名稱ToolStripMenuItem.Click += new System.EventHandler(this.修正權證名稱ToolStripMenuItem_Click);
            // 
            // 轉申請發行TXTToolStripMenuItem
            // 
            this.轉申請發行TXTToolStripMenuItem.Name = "轉申請發行TXTToolStripMenuItem";
            this.轉申請發行TXTToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.轉申請發行TXTToolStripMenuItem.Text = "轉申請發行TXT";
            this.轉申請發行TXTToolStripMenuItem.Click += new System.EventHandler(this.轉申請發行TXTToolStripMenuItem_Click);
            // 
            // 自動申請發行TXTToolStripMenuItem
            // 
            this.自動申請發行TXTToolStripMenuItem.Name = "自動申請發行TXTToolStripMenuItem";
            this.自動申請發行TXTToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.自動申請發行TXTToolStripMenuItem.Text = "自動申請發行TXT";
            this.自動申請發行TXTToolStripMenuItem.Click += new System.EventHandler(this.自動申請發行TXTToolStripMenuItem_Click);
            // 
            // 權證系統上傳檔ToolStripMenuItem
            // 
            this.權證系統上傳檔ToolStripMenuItem.Name = "權證系統上傳檔ToolStripMenuItem";
            this.權證系統上傳檔ToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.權證系統上傳檔ToolStripMenuItem.Text = "發行上傳檔";
            this.權證系統上傳檔ToolStripMenuItem.Click += new System.EventHandler(this.權證系統上傳檔ToolStripMenuItem_Click);
            // 
            // 增額上傳檔ToolStripMenuItem
            // 
            this.增額上傳檔ToolStripMenuItem.Name = "增額上傳檔ToolStripMenuItem";
            this.增額上傳檔ToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.增額上傳檔ToolStripMenuItem.Text = "增額上傳檔";
            this.增額上傳檔ToolStripMenuItem.Click += new System.EventHandler(this.增額上傳檔ToolStripMenuItem_Click);
            // 
            // 關係人列表ToolStripMenuItem
            // 
            this.關係人列表ToolStripMenuItem.Name = "關係人列表ToolStripMenuItem";
            this.關係人列表ToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.關係人列表ToolStripMenuItem.Text = "關係人列表";
            this.關係人列表ToolStripMenuItem.Click += new System.EventHandler(this.關係人列表ToolStripMenuItem_Click);
            // 
            // 修改檔案名稱ToolStripMenuItem
            // 
            this.修改檔案名稱ToolStripMenuItem.Name = "修改檔案名稱ToolStripMenuItem";
            this.修改檔案名稱ToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.修改檔案名稱ToolStripMenuItem.Text = "修改檔案名稱";
            this.修改檔案名稱ToolStripMenuItem.Click += new System.EventHandler(this.修改檔案名稱ToolStripMenuItem_Click);
            // 
            // 財工ToolStripMenuItem
            // 
            this.財工ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.詳細LOGToolStripMenuItem});
            this.財工ToolStripMenuItem.Name = "財工ToolStripMenuItem";
            this.財工ToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.財工ToolStripMenuItem.Text = "財工";
            // 
            // 詳細LOGToolStripMenuItem
            // 
            this.詳細LOGToolStripMenuItem.Name = "詳細LOGToolStripMenuItem";
            this.詳細LOGToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
            this.詳細LOGToolStripMenuItem.Text = "詳細LOG";
            this.詳細LOGToolStripMenuItem.Click += new System.EventHandler(this.詳細LOGToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.查詢及訊息ToolStripMenuItem,
            this.發行增額總表ToolStripMenuItem,
            this.traderToolStripMenuItem,
            this.行政ToolStripMenuItem,
            this.財工ToolStripMenuItem,
            this.toolStripComboBox1,
            this.toolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(799, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripComboBox1
            // 
            this.toolStripComboBox1.DropDownWidth = 85;
            this.toolStripComboBox1.Name = "toolStripComboBox1";
            this.toolStripComboBox1.Size = new System.Drawing.Size(100, 24);
            this.toolStripComboBox1.SelectedIndexChanged += new System.EventHandler(this.toolStripComboBox1_SelectedIndexChanged);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(12, 24);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 28);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.tabControl1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.monthCalendar1);
            this.splitContainer1.Size = new System.Drawing.Size(799, 454);
            this.splitContainer1.SplitterDistance = 576;
            this.splitContainer1.SplitterWidth = 1;
            this.splitContainer1.TabIndex = 1;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(576, 454);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Transparent;
            this.tabPage2.Controls.Add(this.ultraGrid2);
            this.tabPage2.Controls.Add(this.toolStrip1);
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(568, 424);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Announcement";
            // 
            // ultraGrid2
            // 
            this.ultraGrid2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ultraGrid2.Location = new System.Drawing.Point(3, 3);
            this.ultraGrid2.Name = "ultraGrid2";
            this.ultraGrid2.Size = new System.Drawing.Size(562, 393);
            this.ultraGrid2.TabIndex = 2;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.toolStripTextBox1,
            this.toolStripButton1});
            this.toolStrip1.Location = new System.Drawing.Point(3, 396);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(562, 25);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(62, 22);
            this.toolStripLabel1.Text = "新增公告: ";
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(445, 25);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripButton1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.toolStripButton1.Size = new System.Drawing.Size(40, 22);
            this.toolStripButton1.Text = "Add!";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.ultraGrid1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(568, 428);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Information";
            // 
            // ultraGrid1
            // 
            this.ultraGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ultraGrid1.Location = new System.Drawing.Point(3, 3);
            this.ultraGrid1.Name = "ultraGrid1";
            this.ultraGrid1.Size = new System.Drawing.Size(562, 422);
            this.ultraGrid1.TabIndex = 0;
            this.ultraGrid1.InitializeRow += new Infragistics.Win.UltraWinGrid.InitializeRowEventHandler(this.ultraGrid1_InitializeRow);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.CalendarDimensions = new System.Drawing.Size(1, 3);
            this.monthCalendar1.Location = new System.Drawing.Point(0, -12);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(452, 1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "說明文件";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Click += new System.EventHandler(this.Manual_Click);
            // 
            // 非本季標的額度預估ToolStripMenuItem
            // 
            this.非本季標的額度預估ToolStripMenuItem.Name = "非本季標的額度預估ToolStripMenuItem";
            this.非本季標的額度預估ToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.非本季標的額度預估ToolStripMenuItem.Text = "非本季標的額度預估";
            this.非本季標的額度預估ToolStripMenuItem.Click += new System.EventHandler(this.非本季標的額度預估ToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(799, 482);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("微軟正黑體", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "MainForm";
            this.Text = "權證小幫手";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ultraGrid2)).EndInit();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ultraGrid1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem 查詢及訊息ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 標的SummaryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 標的發行檢查ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem put發行檢查ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 已發行權證ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 可增額列表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 發行增額總表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 搶額度總表含增額ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 發行總表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 增額總表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem traderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 發行條件輸入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 增額條件輸入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 行政ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 可增額列表ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 試算表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 轉申請發行TXTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 權證系統上傳檔ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 關係人列表ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 財工ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 詳細LOGToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private Infragistics.Win.UltraWinGrid.UltraGrid ultraGrid1;
        private Infragistics.Win.UltraWinGrid.UltraGrid ultraGrid2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripMenuItem 代理人發行條件輸入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 代理人增額條件輸入ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 增額上傳檔ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 已發權證條件發行ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修正權證名稱ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 修改檔案名稱ToolStripMenuItem;
        private System.Windows.Forms.ToolStripComboBox toolStripComboBox1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 自動申請發行TXTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 特殊標的ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 建議VolToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 到期釋出額度ToolStripMenuItem;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem 發行參數設定ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 非本季標的額度預估ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 發行篩選ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 發行矩陣設定ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 原始參數查詢ToolStripMenuItem;
    }
}

