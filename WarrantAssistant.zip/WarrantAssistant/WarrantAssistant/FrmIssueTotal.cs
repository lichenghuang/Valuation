﻿#define To39
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Infragistics.Win.UltraWinGrid;
using System.Data.SqlClient;
using EDLib.SQL;
using System.IO;
using System.Threading.Tasks;
using System.Configuration;
namespace WarrantAssistant
{
    public partial class FrmIssueTotal:Form
    {
        private DataTable dt = new DataTable();
        private DataTable back_dt = new DataTable();//UpdateRecord()時用來比對更改資料
        private Dictionary<string,Dictionary<string,string>> dt_record = new Dictionary<string, Dictionary<string, string>>();
        private Dictionary<string, string> dt_recordByTrader = new Dictionary<string, string>();//顯示上一筆的更改紀錄
        private DataTable updaterecord_dt = new DataTable();//當有更改資料時，用來記錄那些欄位更改
        private Dictionary<string, double> UidMaxCR_C = new Dictionary<string, double>();
        private Dictionary<string, double> UidMaxCR_P = new Dictionary<string, double>();
        private List<string> ColumnName = new List<string>();
        Dictionary<string, string> sqlTogrid = new Dictionary<string, string>();
        private string userID = GlobalVar.globalParameter.userID;
        private bool isEdit = false;

        DateTime lastDate = EDLib.TradeDate.LastNTradeDate(1);

        public SqlConnection conn = new SqlConnection(GlobalVar.loginSet.warrantassistant45);

        public Dictionary<string, double> wname2result = new Dictionary<string, double>();
        //在10:40左右額度結果出來後，用來記錄要搶額度的權證，哪些改為用10000張發行
        public List<string> changeTo_1w = new List<string>();
        //用來記需要搶額度的權證
        public List<string> Iscompete = new List<string>();
        List<string> Market30 = new List<string>();//市值前20大
        List<string> IsSpecial = new List<string>();//特殊標的
        List<string> IsIndex = new List<string>();//臺灣50指數,臺灣中型100指數,櫃買富櫃50指
        public double NonSpecialCallPutRatio = Convert.ToDouble(ConfigurationManager.AppSettings["NonSpecialCallPutRatio"].ToString());
        public double SpecialCallPutRatio = Convert.ToDouble(ConfigurationManager.AppSettings["SpecialCallPutRatio"].ToString());
        public double SpecialKGIALLPutRatio = Convert.ToDouble(ConfigurationManager.AppSettings["SpecialKGIALLPutRatio"].ToString());
        public double ISTOP30MaxIssue = Convert.ToDouble(ConfigurationManager.AppSettings["ISTOP30MaxIssue"].ToString());
        public double NonTOP30MaxIssue = Convert.ToDouble(ConfigurationManager.AppSettings["NonTOP30MaxIssue"].ToString());
        Dictionary<string, UidPutCallDeltaOne> UidDeltaOne = new Dictionary<string, UidPutCallDeltaOne>();
        private static Dictionary<int, string> reasonString = new Dictionary<int, string> {
            { 0," "},
            { 1,"技術面偏多，股價持續看好，因此發行認購權證吸引投資人。" },
            { 2,"基本面良好，股價具有漲升的條件，因此發行認購權證吸引投資人。"},
            { 3, "營運動能具提升潛力，因此發行認購權證吸引投資人。"},
            { 4, "提供投資人槓桿避險工具"},
            { 5, "持續針對不同的履約條件、存續期間及認購認售等發行新條件，提供投資人更多元投資選擇"}
        };
        public FrmIssueTotal() {
            InitializeComponent();
        }

        private void FrmIssueTotal_Load(object sender, EventArgs e) {
            InitialGrid();
            //sqlTogrid.Add("WarrantName", "權證名稱");
            sqlTogrid.Add("1500W", "Apply1500W" );
            sqlTogrid.Add("類型","Type");
            sqlTogrid.Add("CP", "CP");
            sqlTogrid.Add("履約價", "K");
            sqlTogrid.Add("期間", "T");
            sqlTogrid.Add("行使比例","CR");
            sqlTogrid.Add("IV", "IV");
            sqlTogrid.Add("重設比", "ResetR");
            sqlTogrid.Add("界限比", "BarrierR");
            sqlTogrid.Add("張數", "IssueNum");
            sqlTogrid.Add("獎勵", "UseReward");
            LoadMaxCR();
            LoadData();
            SetUpdateRecord();
            LoadIsSpecial();
            LoadMarket30();
            LoadIsIndex();

            
            
        }

        private void InitialGrid() {
            dt.Columns.Add("市場", typeof(string));
            dt.Columns.Add("序號", typeof(string));
            dt.Columns.Add("交易員", typeof(string));
            dt.Columns.Add("權證名稱", typeof(string));
            dt.Columns.Add("發行價格", typeof(double));
            dt.Columns.Add("1500W", typeof(string));
            dt.Columns.Add("標的代號", typeof(string));
            dt.Columns.Add("類型", typeof(string));
            dt.Columns.Add("CP", typeof(string));
            dt.Columns.Add("股價", typeof(double));
            dt.Columns.Add("履約價", typeof(double));
            dt.Columns.Add("期間", typeof(int));
            dt.Columns.Add("行使比例", typeof(double));
            dt.Columns.Add("HV", typeof(double));
            dt.Columns.Add("IV", typeof(double));
            dt.Columns.Add("IVOri", typeof(double));
            dt.Columns.Add("重設比", typeof(double));
            dt.Columns.Add("界限比", typeof(double));
            dt.Columns.Add("財務費用", typeof(double));
            dt.Columns.Add("張數", typeof(double));
            dt.Columns.Add("約當張數", typeof(double));
            dt.Columns.Add("額度結果", typeof(double));
            dt.Columns.Add("額度", typeof(double));
            dt.Columns.Add("可發行檔數", typeof(double));
            dt.Columns.Add("獎勵額度", typeof(double));
            dt.Columns.Add("順位", typeof(string));
            dt.Columns.Add("獎勵", typeof(string));
            dt.Columns.Add("發行原因", typeof(string));

            ultraGrid1.DataSource = dt;
            UltraGridBand band0 = ultraGrid1.DisplayLayout.Bands[0];

            band0.Columns["張數"].Format = "N0";
            band0.Columns["約當張數"].Format = "N0";
            band0.Columns["額度結果"].Format = "N0";
            band0.Columns["額度"].Format = "N0";
            band0.Columns["獎勵額度"].Format = "N0";

            band0.Columns["交易員"].Width = 60;
            band0.Columns["權證名稱"].Width = 150;
            band0.Columns["發行價格"].Width = 70;
            band0.Columns["標的代號"].Width = 70;
            band0.Columns["1500W"].Width = 70;
            band0.Columns["市場"].Width = 50;
            band0.Columns["類型"].Width = 70;
            band0.Columns["CP"].Width = 40;
            band0.Columns["股價"].Width = 70;
            band0.Columns["履約價"].Width = 70;
            band0.Columns["期間"].Width = 40;
            band0.Columns["行使比例"].Width = 70;
            band0.Columns["HV"].Width = 40;
            band0.Columns["IV"].Width = 40;
            band0.Columns["重設比"].Width = 70;
            band0.Columns["界限比"].Width = 70;
            band0.Columns["財務費用"].Width = 70;
            band0.Columns["張數"].Width = 80;
            band0.Columns["約當張數"].Width = 80;
            band0.Columns["額度結果"].Width = 80;
            band0.Columns["額度"].Width = 80;
            band0.Columns["可發行檔數"].Width = 100;
            band0.Columns["獎勵額度"].Width = 80;
            band0.Columns["獎勵"].Width = 40;
            band0.Columns["順位"].Width = 40;
            band0.Columns["發行原因"].Width = 300;

            band0.Columns["1500W"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Center;
            band0.Columns["標的代號"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Center;
            band0.Columns["類型"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Center;
            band0.Columns["CP"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Center;
            band0.Columns["期間"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Center;
            band0.Columns["發行價格"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right;
            band0.Columns["股價"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right;
            band0.Columns["履約價"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right;
            band0.Columns["HV"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right;
            band0.Columns["IV"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right;
            band0.Columns["重設比"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right;
            band0.Columns["界限比"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right;
            band0.Columns["財務費用"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right;
            band0.Columns["張數"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right;
            band0.Columns["約當張數"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right;
            band0.Columns["額度結果"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right;
            band0.Columns["額度"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right;
            band0.Columns["獎勵額度"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Right;
            band0.Columns["獎勵"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Center;
            band0.Columns["順位"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Center;
            band0.Columns["發行原因"].CellAppearance.TextHAlign = Infragistics.Win.HAlign.Left;

            band0.Override.HeaderAppearance.TextHAlign = Infragistics.Win.HAlign.Left;

            band0.Columns["序號"].Hidden = true;
            band0.Columns["IVOri"].Hidden = true;

            // To sort multi-column using SortedColumns property
            // This enables multi-column sorting
            this.ultraGrid1.DisplayLayout.Override.HeaderClickAction = Infragistics.Win.UltraWinGrid.HeaderClickAction.SortMulti;

            // It is good practice to clear the sorted columns collection
            band0.SortedColumns.Clear();

            SetButton();
        }
        private void SetUpdateRecord()
        {
            updaterecord_dt.Columns.Add("serialNum", typeof(string));
            updaterecord_dt.Columns.Add("dataname", typeof(string));
            updaterecord_dt.Columns.Add("fromvalue", typeof(string));
            updaterecord_dt.Columns.Add("tovalue", typeof(string));
        }
        private void LoadIsSpecial()
        {

            string sql_special = $@"SELECT  DISTINCT  [UID]
                                      FROM [WarrantAssistant].[dbo].[SpecialStock]
                                      WHERE [Type] in ('B','R','KY','O')
                                      AND [DataDate] >=(select Max([Datadate]) FROM [WarrantAssistant].[dbo].[SpecialStock])";
            DataTable dv_special = MSSQL.ExecSqlQry(sql_special, GlobalVar.loginSet.warrantassistant45);

            foreach (DataRow dr in dv_special.Rows)
            {
                string uid = dr["UID"].ToString();
                if (!IsSpecial.Contains(uid))
                    IsSpecial.Add(uid);
            }
        }
        private void LoadMarket30()
        {
            Market30.Clear();
            //市值前30大的表

            string sql_M = $@"SELECT  DISTINCT  [UID]
                              FROM [WarrantAssistant].[dbo].[SpecialStock]
                              WHERE [Type] = 'M'
                              AND [DataDate] >=(select Max([Datadate]) FROM [WarrantAssistant].[dbo].[SpecialStock])";
            DataTable dv_M = MSSQL.ExecSqlQry(sql_M, GlobalVar.loginSet.warrantassistant45);

            foreach (DataRow dr in dv_M.Rows)
            {
                string uid = dr["UID"].ToString();
                if (!Market30.Contains(uid))
                    Market30.Add(uid);
            }
        }
        private void LoadIsIndex()
        {

            string sql_indexTW50 = $@"SELECT [UID] FROM [TwData].[dbo].[IndexUnderlying]
                                      WHERE [IndexType] = 'TW50 Index' 
                                      AND [DataDate] = (SELECT MAX(DataDate) FROM [TwData].[dbo].[IndexUnderlying]
                                      WHERE [IndexType] = 'TW50 Index')";
            string sql_indexTWMC = $@"SELECT [UID] FROM [TwData].[dbo].[IndexUnderlying]
                                      WHERE [IndexType] = 'TWMC Index' 
                                      AND [DataDate] = (SELECT MAX(DataDate) FROM [TwData].[dbo].[IndexUnderlying]
                                      WHERE [IndexType] = 'TWMC Index')";
            string sql_indexGTSM50 = $@"SELECT [UID] FROM [TwData].[dbo].[IndexUnderlying]
                                      WHERE [IndexType] = 'GTSM50 Index' 
                                      AND [DataDate] = (SELECT MAX(DataDate) FROM [TwData].[dbo].[IndexUnderlying]
                                      WHERE [IndexType] = 'GTSM50 Index')";
            DataTable dv_indexTW50 = MSSQL.ExecSqlQry(sql_indexTW50, GlobalVar.loginSet.twData);
            DataTable dv_indexTWMC = MSSQL.ExecSqlQry(sql_indexTWMC, GlobalVar.loginSet.twData);
            DataTable dv_indexGTSM50 = MSSQL.ExecSqlQry(sql_indexGTSM50, GlobalVar.loginSet.twData);

            foreach (DataRow dr in dv_indexTW50.Rows)
            {
                string uid = dr["UID"].ToString();
                if (!IsIndex.Contains(uid))
                    IsIndex.Add(uid);
            }
            foreach (DataRow dr in dv_indexTWMC.Rows)
            {
                string uid = dr["UID"].ToString();
                if (!IsIndex.Contains(uid))
                    IsIndex.Add(uid);
            }
            foreach (DataRow dr in dv_indexGTSM50.Rows)
            {
                string uid = dr["UID"].ToString();
                if (!IsIndex.Contains(uid))
                    IsIndex.Add(uid);
            }
        }
        private void LoadMaxCR()
        {
            UidMaxCR_C.Clear();
            UidMaxCR_P.Clear();
            string sql = $@"SELECT 
                          [標的代號] AS [UID]
	                      ,[權證類別代號] AS [CP]
                          ,MAX([最新執行比例]) AS [CR] 
                      FROM [TwCMData].[dbo].[Warrant總表]
                      WHERE [日期] = '{lastDate.ToString("yyyyMMdd")}' AND [券商代號] = '9200' AND [上市日期] <= '{DateTime.Today.ToString("yyyyMMdd")}' AND [最後交易日] >= '{DateTime.Today.ToString("yyyyMMdd")}' AND [權證類別代號] IN ('c','p') AND LEFT([標的代號],1) <> 'T' AND  LEFT([標的代號],2) <> '00' 
                      GROUP BY [標的代號],[權證類別代號]";
            DataTable dt = MSSQL.ExecSqlQry(sql, GlobalVar.loginSet.twCMData);
            foreach (DataRow dr in dt.Rows)
            {
                string uid = dr["UID"].ToString();

                string cp = dr["CP"].ToString();
                double cr = Convert.ToDouble(dr["CR"].ToString());
                if (cp == "c")
                    UidMaxCR_C.Add(uid, cr);
                if (cp == "p")
                    UidMaxCR_P.Add(uid, cr);
            }
        }
        private void LoadData() {
            try {
                UidDeltaOne.Clear();

                dt.Rows.Clear();
                dt_record.Clear();
                dt_recordByTrader.Clear();
                //Load DeltaOne

                string sql_deltaone = $@"SELECT  [UnderlyingID], [KgiCallDeltaOne], [KgiPutDeltaOne], [KgiCallPutRatio]
                                        ,[AllCallDeltaOne], [AllPutDeltaOne], [KgiAllPutRatio], [YuanPutDeltaOne], [KgiPutNum]
                                        FROM [WarrantAssistant].[dbo].[WarrantIssueDeltaOne]
                                        WHERE [DateTime]='{DateTime.Today.ToString("yyyyMMdd")}'";
                DataTable dv_deltaone = MSSQL.ExecSqlQry(sql_deltaone, GlobalVar.loginSet.warrantassistant45);

                foreach (DataRow dr in dv_deltaone.Rows)
                {
                    string uid_ = dr["UnderlyingID"].ToString();
                    double Kgi_CallDeltaOne = Math.Round(Convert.ToDouble(dr["KgiCallDeltaOne"].ToString()), 2);
                    double Kgi_PutDeltaOne = Math.Round(Convert.ToDouble(dr["KgiPutDeltaOne"].ToString()), 2);
                    double Kgi_CallPutRatio = Convert.ToDouble(dr["KgiCallPutRatio"].ToString());
                    double All_CallDeltaOne = Math.Round(Convert.ToDouble(dr["AllCallDeltaOne"].ToString()), 2);
                    double All_PutDeltaOne = Math.Round(Convert.ToDouble(dr["AllPutDeltaOne"].ToString()), 2);
                    double KgiAll_PutRatio = Convert.ToDouble(dr["KgiAllPutRatio"].ToString());
                    double Yuan_PutDeltaOne = Convert.ToDouble(dr["YuanPutDeltaOne"].ToString());
                    int Kgi_PutNum = Convert.ToInt32(dr["KgiPutNum"].ToString());
                    if (!UidDeltaOne.ContainsKey(uid_))
                        UidDeltaOne.Add(uid_, new UidPutCallDeltaOne(uid_, Kgi_CallDeltaOne, Kgi_PutDeltaOne, Kgi_CallPutRatio, All_CallDeltaOne, All_PutDeltaOne, KgiAll_PutRatio, Yuan_PutDeltaOne, Kgi_PutNum));
                }

                string sql = $@"SELECT  a.SerialNumber
                                      ,a.TraderID
	                                  ,b.WarrantName
	                                  ,a.UnderlyingID
                                      ,a.Apply1500W
	                                  ,b.Market
	                                  ,a.Type
	                                  ,a.CP
	                                  ,IsNull(c.MPrice,0) MPrice
                                      ,a.K
                                      ,a.T
                                      ,a.R
                                      ,a.HV
                                      ,CASE WHEN a.Apply1500W='Y' THEN a.IVNew ELSE a.IV END IVNew
                                      ,a.ResetR
                                      ,a.BarrierR
                                      ,a.FinancialR
                                      ,a.IssueNum
                                      ,b.EquivalentNum
                                      ,b.Result
                                      ,a.IV
                                      ,CASE WHEN a.CP='C' THEN d.Reason ELSE d.ReasonP END Reason
                                      ,a.UseReward
                                      ,IsNull(Floor(E.[WarrantAvailableShares] * {GlobalVar.globalParameter.givenRewardPercent} - IsNull(F.[UsedRewardNum],0)), 0) AS RewardCredit
                                      ,ISNULL(FLOOR(E.CanIssue),0) AS CanIssue
                                  FROM [WarrantAssistant].[dbo].[ApplyOfficial] a
                                  LEFT JOIN [WarrantAssistant].[dbo].[ApplyTotalList] b ON a.SerialNumber=b.SerialNum
                                  LEFT JOIN [WarrantAssistant].[dbo].[WarrantPrices] c on a.UnderlyingID=c.CommodityID
                                  LEFT JOIN Underlying_TraderIssue d on a.UnderlyingID=d.UID 
                                  LEFT JOIN (SELECT [UID], [CanIssue], [WarrantAvailableShares] FROM [WarrantAssistant].[dbo].[WarrantUnderlyingCreditNew] WHERE [UpdateTime] > '{DateTime.Today.ToString("yyyyMMdd")}' ) as E on a.UnderlyingID = E.[UID]
                                  LEFT JOIN [WarrantAssistant].[dbo].[WarrantReward] F on a.UnderlyingID=F.UnderlyingID
                                  ORDER BY b.Market desc, a.Type, a.CP, a.UnderlyingID, SUBSTRING(a.SerialNumber,9,7),CONVERT(INT,SUBSTRING(a.SerialNumber,18,LEN(a.SerialNumber)-17))"; //or (a.UnderlyingID = 'IX0001' and d.UID ='TWA00')

                DataView dv = DeriLib.Util.ExecSqlQry(sql, GlobalVar.loginSet.warrantassistant45);

                foreach (DataRowView drv in dv) {
                    DataRow dr = dt.NewRow();

                    dr["序號"] = drv["SerialNumber"].ToString();
                    dr["交易員"] = drv["TraderID"].ToString().TrimStart('0');
                    dr["權證名稱"] = drv["WarrantName"].ToString();
                    string uid = drv["UnderlyingID"].ToString(); 
                    dr["標的代號"] = drv["UnderlyingID"].ToString();
                    //wclass為小寫  cp為大寫
                    CallPutType cp = drv["CP"].ToString() == "C" ? CallPutType.Call : CallPutType.Put;
                    dr["CP"] = drv["CP"].ToString();

                    dr["1500W"] = drv["Apply1500W"].ToString();
                    dr["市場"] = drv["Market"].ToString();
                    dr["張數"] = drv["IssueNum"];
                    dr["約當張數"] = drv["EquivalentNum"];
                    dr["額度結果"] = drv["Result"];
                    double canIssue = Convert.ToDouble(drv["CanIssue"]);
                    dr["額度"] = canIssue;
                    double canIssueNum = 0;//可發行檔數
                    
                    if ((double)(canIssue / 5000) < 1)
                        canIssueNum = 1;
                    else
                    {
                        double maxCR = 0;
                        if(drv["CP"].ToString() == "C")
                        {
                            if (UidMaxCR_C.ContainsKey(uid))
                                maxCR = UidMaxCR_C[uid];
                        }
                        if (drv["CP"].ToString() == "P")
                        {
                            if (UidMaxCR_P.ContainsKey(uid))
                                maxCR = UidMaxCR_P[uid];
                        }
                        if (maxCR > 0)
                            canIssueNum = Math.Round((double)canIssue / (5000 * maxCR),1);

                    }
                    
                    
                        
                    dr["可發行檔數"] = canIssueNum;
                    dr["IVOri"] = drv["IV"];
                    dr["獎勵"] = drv["UseReward"];
                   
                    double underlyingPrice = 0.0;
                    underlyingPrice = Convert.ToDouble(drv["MPrice"]);
                    dr["股價"] = underlyingPrice;
                    double k = Convert.ToDouble(drv["K"]);
                    dr["履約價"] = k;
                    int t = Convert.ToInt32(drv["T"]);
                    dr["期間"] = t;
                    double cr = Convert.ToDouble(drv["R"]);
                    dr["行使比例"] = cr;
                    dr["HV"] = Convert.ToDouble(drv["HV"]);
                    double vol = Convert.ToDouble(drv["IVNew"]) / 100;
                    dr["IV"] = Convert.ToDouble(drv["IVNew"]);

                    double resetR = Convert.ToDouble(drv["ResetR"]) / 100;
                    dr["重設比"] = Convert.ToDouble(drv["ResetR"]);
                    //double barrierR = Convert.ToDouble(drv["BarrierR"]);
                    dr["界限比"] = Convert.ToDouble(drv["BarrierR"]);
                    double financialR = Convert.ToDouble(drv["FinancialR"]) / 100;
                    dr["財務費用"] = Convert.ToDouble(drv["FinancialR"]);
                    string warrantType = drv["Type"].ToString();
                    dr["類型"] = warrantType;
                    
                    dr["發行原因"] = drv["Reason"] == DBNull.Value ? " " : reasonString[Convert.ToInt32(drv["Reason"])];


                    double rewardcredit = Convert.ToDouble(drv["RewardCredit"].ToString());
                    dr["獎勵額度"] = rewardcredit;
                    double price = 0.0;
                    if (underlyingPrice != 0) {
                        if (warrantType == "牛熊證")
                            price = Pricing.BullBearWarrantPrice(cp, underlyingPrice, resetR, GlobalVar.globalParameter.interestRate, vol, t, financialR, cr);
                        else if (warrantType == "重設型")
                            price = Pricing.ResetWarrantPrice(cp, underlyingPrice, resetR, GlobalVar.globalParameter.interestRate, vol, t, cr);
                        else
                            price = Pricing.NormalWarrantPrice(cp, underlyingPrice, k, GlobalVar.globalParameter.interestRate, vol, t, cr);
                    }
       
                    dr["發行價格"] = Math.Round(price, 2);

                    dt.Rows.Add(dr);
                }
                foreach(DataColumn dc in dt.Columns)
                {
                    if(!ColumnName.Contains(dc.ColumnName))
                    ColumnName.Add(dc.ColumnName);
                }

                //抓更新紀錄的資料

                string sql_record = $@"SELECT A.[SerialNumber], A.[DataName], A.[UpdateCount], B.[FromValue], B.[TraderID]
                                    FROM (SELECT [SerialNumber], [DataName], MAX([UpdateCount]) AS UpdateCount
                                          FROM [WarrantAssistant].[dbo].[ApplyTotalRecord]
                                          WHERE [UpdateTime] >= CONVERT(varchar, getdate(), 112) 
                                          GROUP BY [SerialNumber] ,[DataName]) AS A
                                    LEFT JOIN [WarrantAssistant].[dbo].[ApplyTotalRecord] AS B 
                                    ON A.[SerialNumber] = B.[SerialNumber] AND A.[DataName] =B.[DataName] AND A.[UpdateCount] =B.[UpdateCount]
                                    WHERE A.[UpdateCount] > 0 AND A.[UpdateCount] < 9999";
                DataTable dv_record = MSSQL.ExecSqlQry(sql_record, GlobalVar.loginSet.warrantassistant45);

                //存進record table
                foreach (DataRow dr in dv_record.Rows)
                {
                    string serialNum = dr["SerialNumber"].ToString();
                    string dataName = dr["DataName"].ToString();
                    string FromValue = dr["FromValue"].ToString();
                    string TraderID = dr["TraderID"].ToString().TrimStart('0');
                    if (!dt_record.ContainsKey(serialNum))
                        dt_record.Add(serialNum, new Dictionary<string, string>());
                    dt_record[serialNum].Add(dataName, FromValue);
                    if(!dt_recordByTrader.ContainsKey(serialNum))
                        dt_recordByTrader.Add(serialNum, TraderID);
                }
                Iscompete.Clear();

                string sql2 = $@"SELECT [UnderlyingID]
                          FROM [WarrantAssistant].[dbo].[Apply_71]
                          WHERE len([OriApplyTime])> 0";
                DataTable dt2 = MSSQL.ExecSqlQry(sql2, GlobalVar.loginSet.warrantassistant45);

                foreach (DataRow dr in dt2.Rows)
                {
                    Iscompete.Add(dr["UnderlyingID"].ToString());
                }
                changeTo_1w.Clear();

                string sql_changeTo1w = $@"SELECT [SerialNumber] 
                                    FROM [WarrantAssistant].[dbo].[ApplyTotalRecord]
                                    WHERE [UpdateTime] >= CONVERT(VARCHAR, GETDATE(), 112) AND [ApplyKind] = '3'";
                DataTable dt_changeTo1w = MSSQL.ExecSqlQry(sql_changeTo1w, GlobalVar.loginSet.warrantassistant45);

                foreach (DataRow dr in dt_changeTo1w.Rows)
                {
                    string serialnum = dr["SerialNumber"].ToString();
                    changeTo_1w.Add(serialnum);
                }

                string sqltemp = $@"SELECT A.[SerialNum]
                              ,CASE WHEN A.[ApplyKind]='1' THEN '新發' ELSE '增額' END ApplyKind
                              ,A.[UnderlyingID]
                              ,A.[CR]
                              ,A.[CP]
                              ,A.[IssueNum]
                              ,A.[UseReward] 
                              ,B.[ApplyTime]
                              ,B.[OriApplyTime]
                          FROM [WarrantAssistant].[dbo].[ApplyTotalList] A
                          LEFT JOIN [WarrantAssistant].[dbo].[Apply_71] B on A.[SerialNum] = B.[SerialNum] ";
                DataTable dvtemp = MSSQL.ExecSqlQry(sqltemp, GlobalVar.loginSet.warrantassistant45);

                foreach (DataRow dr in dvtemp.Rows)
                {
                    bool needadd = true;
                    string uid = dr["UnderlyingID"].ToString();
                    string cp = dr["UnderlyingID"].ToString();
                    string isreward = dr["UseReward"].ToString();
                    string apytime = dr["ApplyTime"].ToString();//時間的全部字串
                    string applyTime = "";
                    if (apytime != string.Empty)
                        applyTime = dr["ApplyTime"].ToString().Substring(0, 2);//時間幾點
                    string oriapplyTime = dr["OriApplyTime"].ToString();
                    double cr = Convert.ToDouble(dr["CR"].ToString());
                    double issueNum = Convert.ToDouble(dr["IssueNum"].ToString());
                    if (UidDeltaOne.ContainsKey(uid))
                    {
                        if (applyTime == "22" || (apytime.Length == 0) && Iscompete.Contains(uid) && isreward == "N")
                            needadd = false;
                        if (needadd)
                        {
                            if (cp == "C")
                            {
                                UidDeltaOne[uid].KgiCallDeltaOne += issueNum * cr;
                                if (UidDeltaOne[uid].KgiPutNum == 0)
                                    UidDeltaOne[uid].KgiCallPutRatio = 100;
                                else
                                    UidDeltaOne[uid].KgiCallPutRatio = Math.Round((double)UidDeltaOne[uid].KgiCallDeltaOne / (double)UidDeltaOne[uid].KgiPutDeltaOne, 4);
                                UidDeltaOne[uid].AllCallDeltaOne += issueNum * cr;
                                if (UidDeltaOne[uid].AllPutDeltaOne == 0)
                                    UidDeltaOne[uid].KgiAllPutRatio = 100;
                                else
                                    UidDeltaOne[uid].KgiAllPutRatio = Math.Round((double)UidDeltaOne[uid].KgiPutDeltaOne / (double)UidDeltaOne[uid].AllPutDeltaOne, 4);
                            }
                            else
                            {
                                UidDeltaOne[uid].KgiPutDeltaOne += issueNum * cr;
                                UidDeltaOne[uid].KgiCallPutRatio = Math.Round((double)UidDeltaOne[uid].KgiCallDeltaOne / (double)UidDeltaOne[uid].KgiPutDeltaOne, 4);
                                UidDeltaOne[uid].AllPutDeltaOne += issueNum * cr;
                                UidDeltaOne[uid].KgiAllPutRatio = Math.Round((double)UidDeltaOne[uid].KgiPutDeltaOne / (double)UidDeltaOne[uid].AllPutDeltaOne, 4);
                                UidDeltaOne[uid].KgiPutNum++;
                            }
                        }
                    }
                }
            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void UpdateData() {
            try {

                string cmdText = "UPDATE [ApplyOfficial] SET K=@K, T=@T, R=@R, HV=@HV, IV=@IV, ResetR=@ResetR, BarrierR=@BarrierR, FinancialR=@FinancialR, Type=@Type, CP=@CP, Apply1500W=@Apply1500W, MDate=@MDate, TempName=@TempName WHERE SerialNumber=@SerialNumber";
                List<SqlParameter> pars = new List<SqlParameter>();
                pars.Add(new SqlParameter("@K", SqlDbType.Float));
                pars.Add(new SqlParameter("@T", SqlDbType.Int));
                pars.Add(new SqlParameter("@R", SqlDbType.Float));
                pars.Add(new SqlParameter("@HV", SqlDbType.Float));
                pars.Add(new SqlParameter("@IV", SqlDbType.Float));
                pars.Add(new SqlParameter("@ResetR", SqlDbType.Float));
                pars.Add(new SqlParameter("@BarrierR", SqlDbType.Float));
                pars.Add(new SqlParameter("@FinancialR", SqlDbType.Float));
                pars.Add(new SqlParameter("@Type", SqlDbType.VarChar));
                pars.Add(new SqlParameter("@CP", SqlDbType.VarChar));
                pars.Add(new SqlParameter("@Apply1500W", SqlDbType.VarChar));
                //pars.Add(new SqlParameter("@TraderID", SqlDbType.VarChar));
                pars.Add(new SqlParameter("@MDate", SqlDbType.DateTime));
                pars.Add(new SqlParameter("@TempName", SqlDbType.VarChar));
                pars.Add(new SqlParameter("@SerialNumber", SqlDbType.VarChar));

                SQLCommandHelper h = new SQLCommandHelper(GlobalVar.loginSet.warrantassistant45, cmdText, pars);

                foreach (Infragistics.Win.UltraWinGrid.UltraGridRow r in ultraGrid1.Rows) {
                    double k = r.Cells["履約價"].Value == DBNull.Value ? 0 : Convert.ToDouble(r.Cells["履約價"].Value);
                    double t = r.Cells["期間"].Value == DBNull.Value ? 0 : Convert.ToDouble(r.Cells["期間"].Value);
                    double cr = r.Cells["行使比例"].Value == DBNull.Value ? 0 : Convert.ToDouble(r.Cells["行使比例"].Value);
                    double hv = r.Cells["HV"].Value == DBNull.Value ? 0 : Convert.ToDouble(r.Cells["HV"].Value);
                    double iv = 0.0;
                    double resetR = r.Cells["重設比"].Value == DBNull.Value ? 0 : Convert.ToDouble(r.Cells["重設比"].Value);
                    double barrierR = r.Cells["界限比"].Value == DBNull.Value ? 0 : Convert.ToDouble(r.Cells["界限比"].Value);
                    double financialR = r.Cells["財務費用"].Value == DBNull.Value ? 0 : Convert.ToDouble(r.Cells["財務費用"].Value);
                    string type = r.Cells["類型"].Value.ToString();
                    string cp = r.Cells["CP"].Value.ToString();
                    string apply1500w = r.Cells["1500W"].Value.ToString();
                    string serialNumber = r.Cells["序號"].Value.ToString();
                   
                    string warrantType = "";

                    DateTime expiryDate = GlobalVar.globalParameter.nextTradeDate3.AddMonths(Convert.ToInt32(t));
                    if (expiryDate.Day == GlobalVar.globalParameter.nextTradeDate3.Day)
                        expiryDate = expiryDate.AddDays(-1);
                    string sqlTemp = $"SELECT TOP 1 TradeDate from TradeDate WHERE IsTrade='Y' AND TradeDate >= '{expiryDate.ToString("yyyy-MM-dd")}'";
                    //DataView dvTemp = DeriLib.Util.ExecSqlQry(sqlTemp, GlobalVar.loginSet.tsquoteSqlConnString);
                    DataTable dvTemp = MSSQL.ExecSqlQry(sqlTemp, GlobalVar.loginSet.tsquoteSqlConnString);
                    foreach (DataRow drTemp in dvTemp.Rows)
                    {
                        expiryDate = Convert.ToDateTime(drTemp["TradeDate"]);
                    }
                    int month = expiryDate.Month;
                    string expiryMonth = month.ToString();
                    if (month >= 10)
                    {
                        if (month == 10)
                            expiryMonth = "A";
                        if (month == 11)
                            expiryMonth = "B";
                        if (month == 12)
                            expiryMonth = "C";
                    }

                    string expiryYear = expiryDate.AddYears(-1).ToString("yyyy");
                    expiryYear = expiryYear.Substring(expiryYear.Length - 1, 1);
                    if (type == "牛熊證")
                    {
                        if (cp == "P")
                            warrantType = "熊";                 
                        else
                            warrantType = "牛";
                    }
                    else
                    {
                        if (cp == "P")
                            warrantType = "售";       
                        else
                            warrantType = "購";      
                    }
                    string tempName = r.Cells["權證名稱"].Value.ToString();
                    int length = tempName.Length;
                    tempName = tempName.Substring(0, length - 5);
                    tempName = tempName + expiryYear + expiryMonth + warrantType;
                    //MessageBox.Show(tempName);
                    if (apply1500w == "Y")
                        iv = r.Cells["IVOri"].Value == DBNull.Value ? 0 : Convert.ToDouble(r.Cells["IVOri"].Value);
                    else
                        iv = r.Cells["IV"].Value == DBNull.Value ? 0 : Convert.ToDouble(r.Cells["IV"].Value);

                    h.SetParameterValue("@K", k);
                    h.SetParameterValue("@T", t);
                    h.SetParameterValue("@R", cr);
                    h.SetParameterValue("@HV", hv);
                    h.SetParameterValue("@IV", iv);
                    h.SetParameterValue("@ResetR", resetR);
                    h.SetParameterValue("@BarrierR", barrierR);
                    h.SetParameterValue("@FinancialR", financialR);
                    h.SetParameterValue("@Type", type);
                    h.SetParameterValue("@CP", cp);
                    h.SetParameterValue("@Apply1500W", apply1500w);
                    //h.SetParameterValue("@TraderID", traderID);
                    h.SetParameterValue("@MDate", DateTime.Now);
                    h.SetParameterValue("@TempName", tempName);
                    h.SetParameterValue("@SerialNumber", serialNumber);
                    h.ExecuteCommand();
                }
                h.Dispose();

                string sql = $@"DELETE FROM [WarrantAssistant].[dbo].[ApplyTotalList] WHERE [ApplyKind]='1'";
                string sql2 = $@"INSERT INTO [WarrantAssistant].[dbo].[ApplyTotalList] ([ApplyKind],[SerialNum],[Market],[UnderlyingID],[WarrantName],[CR] ,[IssueNum],[EquivalentNum],[Credit],[RewardCredit],[Type],[CP],[UseReward],[MarketTmr],[TraderID],[MDate],UserID)
                                SELECT '1',a.SerialNumber, isnull(b.Market, 'TSE'), a.UnderlyingID, a.TempName, a.R, a.IssueNum, ROUND(a.R*a.IssueNum, 2), b.IssueCredit, b.RewardIssueCredit, a.Type, a.CP, a.UseReward,'N', a.TraderID, GETDATE(), a.UserID
                                FROM [WarrantAssistant].[dbo].[ApplyOfficial] a
                                LEFT JOIN [WarrantAssistant].[dbo].[WarrantUnderlyingSummary] b ON a.UnderlyingID=b.UnderlyingID";
                string sql3 = "UPDATE [WarrantAssistant].[dbo].[ApplyTotalList] SET Result=0";
                string sql4 = @"UPDATE [WarrantAssistant].[dbo].[ApplyTotalList] 
                                SET Result= B.Result 
                                FROM [WarrantAssistant].[dbo].[Apply_71] B
                                WHERE [ApplyTotalList].[WarrantName]=B.WarrantName
                                AND [ApplyTotalList].[ApplyKind] = '1'";
                string sql5 = @"UPDATE [WarrantAssistant].[dbo].[ApplyTotalList]
                                SET Result= CASE WHEN [RewardCredit]>=[EquivalentNum] THEN [EquivalentNum] ELSE [RewardCredit] END
                               WHERE [UseReward]='Y'";


                conn.Open();
                MSSQL.ExecSqlCmd(sql, conn);
                MSSQL.ExecSqlCmd(sql2, conn);
                conn.Close();

                //------------------------------------------------------
                string sql6 = "SELECT [SerialNum], [WarrantName] FROM [WarrantAssistant].[dbo].[ApplyTotalList] WHERE [ApplyKind]='1'";
                
                DataTable dv = MSSQL.ExecSqlQry(sql6, GlobalVar.loginSet.warrantassistant45);

                string cmdText_2 = "UPDATE [ApplyTotalList] SET WarrantName=@WarrantName WHERE SerialNum=@SerialNum";
                List<SqlParameter> pars_2 = new List<SqlParameter> {
                    new SqlParameter("@WarrantName", SqlDbType.VarChar),
                    new SqlParameter("@SerialNum", SqlDbType.VarChar)
                };
                SQLCommandHelper h_2 = new SQLCommandHelper(GlobalVar.loginSet.warrantassistant45, cmdText_2, pars_2);

                foreach (DataRow dr in dv.Rows)
                {
                    string serialNum = dr["SerialNum"].ToString();
                    string warrantName = dr["WarrantName"].ToString();

                    string sqlTemp = $"select top (1) WarrantName from (SELECT [WarrantName] FROM [WarrantAssistant].[dbo].[WarrantBasic] WHERE SUBSTRING(WarrantName,1,(len(WarrantName)-3))='{warrantName.Substring(0, warrantName.Length - 1)}' union "
                     + $" SELECT [WarrantName] FROM [WarrantAssistant].[dbo].[ApplyTotalList] WHERE [ApplyKind]='1' AND CONVERT(INT, SUBSTRING([SerialNum], 18 ,LEN([SerialNum])-18 + 1)) <  CONVERT(INT, SUBSTRING('{serialNum}', 18, LEN('{serialNum}')-18 + 1)) AND SUBSTRING(WarrantName,1,(len(WarrantName)-3))='{warrantName.Substring(0, warrantName.Length - 1)}') as tb1 "
                     + " order by SUBSTRING(WarrantName,len(WarrantName)-1,len(WarrantName)) desc";
                    
                    DataTable dvTemp = MSSQL.ExecSqlQry(sqlTemp, GlobalVar.loginSet.warrantassistant45);
                    int count = 0;
                    if (dvTemp.Rows.Count > 0)
                    {
                        string lastWarrantName = dvTemp.Rows[0][0].ToString();
                        if (!int.TryParse(lastWarrantName.Substring(lastWarrantName.Length - 2, 2), out count))
                            MessageBox.Show("parse failed " + lastWarrantName);
                    }

                    //if (dvTemp.Count > 0)
                    //   count += dvTemp.Count;

                    /*sqlTemp = "SELECT [WarrantName] FROM [EDIS].[dbo].[ApplyTotalList] WHERE [ApplyKind]='1' AND [SerialNum]<" + serialNum + " AND SUBSTRING(WarrantName,1,(len(WarrantName)-3))='" + warrantName.Substring(0, warrantName.Length - 1) + "'";
                    dvTemp = DeriLib.Util.ExecSqlQry(sqlTemp, GlobalVar.loginSet.edisSqlConnString);
                    if (dvTemp.Count > 0)
                        count += dvTemp.Count;*/

                    warrantName = warrantName + (count + 1).ToString("0#");

                    h_2.SetParameterValue("@WarrantName", warrantName);
                    h_2.SetParameterValue("@SerialNum", serialNum);
                    h_2.ExecuteCommand();
                }
                h_2.Dispose();
                conn.Open();
                MSSQL.ExecSqlCmd(sql3, conn);
                MSSQL.ExecSqlCmd(sql4, conn);
                MSSQL.ExecSqlCmd(sql5, conn);
                conn.Close();

                UpdateRecord();
                LoadData();
                GlobalUtility.LogInfo("Info", GlobalVar.globalParameter.userID + " 更新發行總表");
            } catch (Exception ex) {
                MessageBox.Show(ex.Message);
            }
        }

        private void UpdateRecord()//紀錄任何權證發行與修改，存在ApplyTotalRecord
        {
            updaterecord_dt.Rows.Clear();
            int length = ultraGrid1.Rows.Count;
            for(int i = length - 1; i >= 0; i--)
            {
                string serialNum = ultraGrid1.Rows[i].Cells[1].Value.ToString();
                try
                {
                    DataRow back_row = back_dt.Select($"序號= '{serialNum}'")[0];
                    foreach (string colname in sqlTogrid.Keys)
                    {
                        if (back_row[colname].ToString() != ultraGrid1.Rows[i].Cells[colname].Value.ToString())
                        {
                            DataRow dr = updaterecord_dt.NewRow();
                            dr["serialNum"] = serialNum;
                            dr["dataname"] = sqlTogrid[colname];
                            dr["fromvalue"] = back_row[colname].ToString();
                            dr["tovalue"] = ultraGrid1.Rows[i].Cells[colname].Value.ToString();
                            updaterecord_dt.Rows.Add(dr);
                        }

                    }
                }
                catch
                {
                    continue;
                }
            }
            
            foreach(DataRow dr in updaterecord_dt.Rows)
            {
                //MessageBox.Show($"{dr["serialNum"].ToString()}  {dr["dataname"].ToString()}  {dr["fromvalue"].ToString()}  {dr["tovalue"].ToString()}");
                
                int count = -1;
                string serialNum = dr["serialNum"].ToString();
                string dataname = dr["dataname"].ToString();
                string fromvalue = dr["fromvalue"].ToString();
                string tovalue = dr["tovalue"].ToString();

                string sql_count = $@"SELECT A.[UpdateCount]
                                    FROM (SELECT [SerialNumber], [DataName], MAX([UpdateCount]) AS UpdateCount
                                          FROM [WarrantAssistant].[dbo].[ApplyTotalRecord]
                                          WHERE [UpdateTime] >= CONVERT(varchar, getdate(), 112)
                                          GROUP BY[SerialNumber],[DataName]) AS A
                                    WHERE A.[UpdateCount] < 9999 AND A.[SerialNumber] ='{serialNum}' AND A.DataName= '{dataname}'";
                DataTable dv_count = MSSQL.ExecSqlQry(sql_count, GlobalVar.loginSet.warrantassistant45);

                foreach (DataRow drr in dv_count.Rows)
                {
                     count = Convert.ToInt32(drr["UpdateCount"].ToString());
                }

                string sql3 = $@"INSERT INTO [WarrantAssistant].[dbo].[ApplyTotalRecord] ([UpdateTime], [UpdateType], [TraderID], [SerialNumber]
                                            , [ApplyKind], [DataName] ,[FromValue], [ToValue], [UpdateCount])
                                           VALUES(GETDATE(), 'UPDATE', '{userID}', {serialNum}, '1','{dataname}','{fromvalue}','{tovalue}',{count + 1})";
                if (count >= 0)
                    MSSQL.ExecSqlCmd(sql3, GlobalVar.loginSet.warrantassistant45);

            }
        }
        private void SetButton() {
            UltraGridBand band0 = ultraGrid1.DisplayLayout.Bands[0];
            if (isEdit) {
                band0.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.Default;
                band0.Override.AllowUpdate = Infragistics.Win.DefaultableBoolean.True;
                band0.Override.AllowDelete = Infragistics.Win.DefaultableBoolean.True;

                band0.Columns["1500W"].CellActivation = Activation.AllowEdit;
                band0.Columns["類型"].CellActivation = Activation.AllowEdit;
                band0.Columns["CP"].CellActivation = Activation.AllowEdit;
                band0.Columns["履約價"].CellActivation = Activation.AllowEdit;
                band0.Columns["期間"].CellActivation = Activation.AllowEdit;
                band0.Columns["HV"].CellActivation = Activation.AllowEdit;
                band0.Columns["IV"].CellActivation = Activation.AllowEdit;
                band0.Columns["重設比"].CellActivation = Activation.AllowEdit;
                band0.Columns["界限比"].CellActivation = Activation.AllowEdit;
                band0.Columns["財務費用"].CellActivation = Activation.AllowEdit;
                band0.Columns["行使比例"].CellActivation = Activation.AllowEdit;
                //band0.Columns["獎勵"].CellActivation = Activation.AllowEdit;

                band0.Columns["交易員"].CellAppearance.BackColor = Color.LightGray;
                band0.Columns["發行價格"].CellAppearance.BackColor = Color.LightGray;
                band0.Columns["標的代號"].CellAppearance.BackColor = Color.LightGray;
                band0.Columns["市場"].CellAppearance.BackColor = Color.LightGray;
                //ultraGrid1.DisplayLayout.Bands[0].Columns["類型"].CellAppearance.BackColor = Color.LightGray;
                band0.Columns["股價"].CellAppearance.BackColor = Color.LightGray;
                //band0.Columns["行使比例"].CellAppearance.BackColor = Color.LightGray;

                toolStripButtonReload.Visible = false;
                toolStripButtonEdit.Visible = false;
                toolStripButtonConfirm.Visible = true;
                toolStripButtonCancel.Visible = true;

                band0.Columns["張數"].Hidden = true;
                band0.Columns["約當張數"].Hidden = true;
                band0.Columns["額度結果"].Hidden = true;

            } else {
                band0.Override.AllowAddNew = Infragistics.Win.UltraWinGrid.AllowAddNew.No;
                band0.Override.AllowUpdate = Infragistics.Win.DefaultableBoolean.True;
                band0.Override.AllowDelete = Infragistics.Win.DefaultableBoolean.False;

                band0.Columns["市場"].CellActivation = Activation.NoEdit;
                band0.Columns["交易員"].CellActivation = Activation.NoEdit;
                band0.Columns["權證名稱"].CellActivation = Activation.NoEdit;
                band0.Columns["發行價格"].CellActivation = Activation.NoEdit;
                band0.Columns["1500W"].CellActivation = Activation.NoEdit;
                band0.Columns["標的代號"].CellActivation = Activation.NoEdit;
                band0.Columns["類型"].CellActivation = Activation.NoEdit;
                band0.Columns["CP"].CellActivation = Activation.NoEdit;
                band0.Columns["股價"].CellActivation = Activation.NoEdit;
                band0.Columns["履約價"].CellActivation = Activation.NoEdit;
                band0.Columns["期間"].CellActivation = Activation.NoEdit;
                band0.Columns["行使比例"].CellActivation = Activation.NoEdit;
                band0.Columns["HV"].CellActivation = Activation.NoEdit;
                band0.Columns["IV"].CellActivation = Activation.NoEdit;
                band0.Columns["重設比"].CellActivation = Activation.NoEdit;
                band0.Columns["界限比"].CellActivation = Activation.NoEdit;
                band0.Columns["財務費用"].CellActivation = Activation.NoEdit;
                band0.Columns["張數"].CellActivation = Activation.NoEdit;
                band0.Columns["約當張數"].CellActivation = Activation.NoEdit;
                band0.Columns["額度結果"].CellActivation = Activation.NoEdit;
                band0.Columns["獎勵"].CellActivation = Activation.NoEdit;

                band0.Columns["交易員"].CellAppearance.BackColor = Color.White;
                band0.Columns["發行價格"].CellAppearance.BackColor = Color.White;
                band0.Columns["標的代號"].CellAppearance.BackColor = Color.White;
                band0.Columns["市場"].CellAppearance.BackColor = Color.White;
                //ultraGrid1.DisplayLayout.Bands[0].Columns["類型"].CellAppearance.BackColor = Color.White;
                band0.Columns["股價"].CellAppearance.BackColor = Color.White;
                band0.Columns["行使比例"].CellAppearance.BackColor = Color.White;

                band0.Columns["張數"].Hidden = false;
                band0.Columns["約當張數"].Hidden = false;
                band0.Columns["額度結果"].Hidden = false;

                toolStripButtonReload.Visible = true;
                toolStripButtonEdit.Visible = true;
                toolStripButtonConfirm.Visible = false;
                toolStripButtonCancel.Visible = false;

                if (GlobalVar.globalParameter.userGroup == "TR") {
                    toolStripButtonEdit.Visible = false;
                }

            }
        }

        private void toolStripButtonReload_Click(object sender, EventArgs e) {
            LoadData();
        }

        private void toolStripButtonEdit_Click(object sender, EventArgs e) {
            isEdit = true;
            LoadData();
            back_dt.Rows.Clear();
            back_dt = dt.Copy();
            SetButton();
        }

        private void toolStripButtonConfirm_Click(object sender, EventArgs e) {
            ultraGrid1.PerformAction(Infragistics.Win.UltraWinGrid.UltraGridAction.ExitEditMode);
            isEdit = false;
            UpdateData();
            SetButton();
            LoadData();
        }

        private void toolStripButtonCancel_Click(object sender, EventArgs e) {
            isEdit = false;
            LoadData();
            SetButton();
        }

        private void ultraGrid1_InitializeLayout(object sender, InitializeLayoutEventArgs e) {
            ultraGrid1.DisplayLayout.Override.RowSelectorHeaderStyle = RowSelectorHeaderStyle.ColumnChooserButton;
        }

        private void ultraGrid1_InitializeRow(object sender, InitializeRowEventArgs e) {
            string serialNum = e.Row.Cells["序號"].Value.ToString();
            string is1500W = "N";
            is1500W = e.Row.Cells["1500W"].Value.ToString();
            string useReward = "N";
            useReward = e.Row.Cells["獎勵"].Value.ToString();
            if (is1500W == "Y")
                e.Row.Cells["1500W"].Appearance.ForeColor = Color.Blue;
            if (useReward == "Y")
            {
                e.Row.Cells["獎勵"].Appearance.BackColor = Color.PapayaWhip;
                e.Row.Cells["獎勵"].Appearance.ForeColor = Color.MediumBlue;
                e.Row.Cells["獎勵"].Appearance.FontData.Bold = Infragistics.Win.DefaultableBoolean.True;
            }
            string underlyingID = "";
            string cp = "C";
            underlyingID = e.Row.Cells["標的代號"].Value.ToString();
            cp = e.Row.Cells["CP"].Value.ToString();
            string issuable = "Y";
            string putIssuable = "Y";
            string toolTip1 = "發行檢查=N";

            string sqlTemp2 = "SELECT [Issuable], [PutIssuable] FROM [WarrantAssistant].[dbo].[WarrantUnderlyingSummary] WHERE UnderlyingID = '" + underlyingID + "'";
            DataView dvTemp2 = DeriLib.Util.ExecSqlQry(sqlTemp2, GlobalVar.loginSet.warrantassistant45);

            foreach (DataRowView drTemp2 in dvTemp2) {
                issuable = drTemp2["Issuable"].ToString();
                putIssuable = drTemp2["PutIssuable"].ToString();
            }
            if (underlyingID != "") {

                if (issuable == "N") {
                    e.Row.ToolTipText = toolTip1;
                    e.Row.Cells["標的代號"].Appearance.ForeColor = Color.Red;
                }

                if (cp == "P" && putIssuable == "N") {
                    e.Row.Cells["CP"].Appearance.ForeColor = Color.Red;
                    e.Row.Cells["CP"].ToolTipText = "Put not issuable";
                }

            }

            double issuePrice = e.Row.Cells["發行價格"].Value == DBNull.Value ? 0 : Convert.ToDouble(e.Row.Cells["發行價格"].Value);
            if (issuePrice <= 0.6 || issuePrice > 3) {
                e.Row.Cells["發行價格"].Appearance.ForeColor = Color.Red;
                e.Row.Cells["發行價格"].ToolTipText = " <= 0.6 or > 3";
            }

            string warrantType = e.Row.Cells["類型"].Value == DBNull.Value ? "一般型" : e.Row.Cells["類型"].Value.ToString();
            double k = e.Row.Cells["履約價"].Value == DBNull.Value ? 0 : Convert.ToDouble(e.Row.Cells["履約價"].Value);
            double underlyingPrice = e.Row.Cells["股價"].Value == DBNull.Value ? 0 : Convert.ToDouble(e.Row.Cells["股價"].Value);

            //Check for moneyness constraint
            e.Row.Cells["履約價"].Appearance.ForeColor = Color.Black;
            if (warrantType != "牛熊證") {
                if ((cp == "C" && k / underlyingPrice >= 1.5) || (cp == "P" && k / underlyingPrice <= 0.5)) {
                    e.Row.Cells["履約價"].Appearance.ForeColor = Color.Red;
                    e.Row.Cells["履約價"].ToolTipText = "履約價超過價外50%";
                }
            }

            if (!isEdit && DateTime.Now.TimeOfDay.TotalMinutes >= GlobalVar.globalParameter.resultTime) {
                string warrantName = e.Row.Cells["權證名稱"].Value.ToString();
                string traderID = e.Row.Cells["交易員"].Value.ToString();
                string applyStatus = "";
                double issueNum = 0.0;
                string applyTime = "";
                string apytime = "";
                string rank = "";
                string oriapplyTime = "";
                issueNum = Convert.ToDouble(e.Row.Cells["張數"].Value);

                double equivalentNum = Convert.ToDouble(e.Row.Cells["約當張數"].Value);
                double result = e.Row.Cells["額度結果"].Value == DBNull.Value ? 0 : Convert.ToDouble(e.Row.Cells["額度結果"].Value);
                double cr = Convert.ToDouble(e.Row.Cells["行使比例"].Value);

                string sqlTemp = "SELECT [ApplyStatus],[ApplyTime], [OriApplyTime] FROM [WarrantAssistant].[dbo].[Apply_71] WHERE SerialNum = '" + serialNum + "'";
                DataView dvTemp = DeriLib.Util.ExecSqlQry(sqlTemp, GlobalVar.loginSet.warrantassistant45);

                foreach (DataRowView drTemp in dvTemp) {
                    applyStatus = drTemp["ApplyStatus"].ToString();
                    applyTime = drTemp["ApplyTime"].ToString().Substring(0, 2);//時間幾點
                    apytime = drTemp["ApplyTime"].ToString();//時間的全部字串
                    rank = drTemp["ApplyTime"].ToString().Substring(6, 2);
                    oriapplyTime = drTemp["OriApplyTime"].ToString();
                }
                if (applyStatus == "排隊中" && issueNum != 10000) {
                    //e.Row.Cells["張數"].Appearance.ForeColor = Color.Red;
                    e.Row.Cells["張數"].ToolTipText = "排隊中";
                }

                if (applyStatus == "X 沒額度") {
                    e.Row.Cells["權證名稱"].Appearance.BackColor = Color.LightGray;
                    e.Row.Cells["權證名稱"].ToolTipText = "沒額度";
                }
                if ((result + 0.00001).CompareTo(equivalentNum) >=0) {
                    e.Row.Cells["權證名稱"].Appearance.BackColor = Color.PaleGreen;
                    e.Row.Cells["權證名稱"].ToolTipText = "額度OK";
                }

                if ((result + 0.00001).CompareTo(equivalentNum) < 0 && result > 0) {
                    e.Row.Cells["權證名稱"].Appearance.BackColor = Color.PaleTurquoise;
                    e.Row.Cells["權證名稱"].ToolTipText = "部分額度";
                    
                }
                if (apytime.Length > 0)
                {
                    //要搶
                    if (oriapplyTime.Length > 0 && applyTime != "22")
                    {
                        e.Row.Cells["順位"].Appearance.BackColor = Color.Bisque;
                        e.Row.Cells["順位"].Value = apytime.Substring(6, 2);
                        e.Row.Cells["順位"].ToolTipText = "需搶額度";
                        if (!wname2result.ContainsKey(warrantName))
                            wname2result.Add(warrantName, result);
                        
                        if((wname2result[warrantName]==0) && (result != 0)&& (userID.TrimStart('0')==traderID))
                        {
                            MessageBox.Show($"{warrantName} 有額度 {result.ToString()} 張");
                        }
                        
                    }
                    else if (applyTime == "22")
                    {
                        e.Row.Cells["順位"].Appearance.BackColor = Color.Aquamarine;
                        e.Row.Cells["順位"].Value = "X";
                        e.Row.Cells["順位"].ToolTipText = "沒額度";
                    }
                    else
                    {
                        e.Row.Cells["順位"].Appearance.BackColor = Color.Aquamarine;
                        e.Row.Cells["順位"].Value = "-";
                        e.Row.Cells["順位"].ToolTipText = "不用搶";
                    }
                }
                else
                {
                    e.Row.Cells["順位"].Appearance.BackColor = Color.Aquamarine;
                    e.Row.Cells["順位"].Value = "-";
                    e.Row.Cells["順位"].ToolTipText = "不用搶";
                }
                /*
                if (applyTime == "10" && oriapplyTime.Length > 0 && issueNum != 10000 && useReward == "N")
                {
                    e.Row.Cells["張數"].Appearance.BackColor = Color.Bisque;
                    e.Row.Cells["張數"].ToolTipText = "要搶，更改為10000張";
                    e.Row.Cells["張數"].Value = 10000;
                }
                */
                if ((changeTo_1w.Contains(serialNum) && useReward == "N") || (Iscompete.Contains(underlyingID) && useReward == "Y"))
                {
                    if (UidDeltaOne.ContainsKey(underlyingID))
                    {
                        int wlength = warrantName.Length;
                        string subwname = warrantName.Substring(0, wlength - 2);

                        string sql_price = $@"SELECT [MPrice]
                                            FROM [WarrantAssistant].[dbo].[WarrantPrices]
                                            WHERE [CommodityID] = '{underlyingID}'";
                        DataTable dt_price = MSSQL.ExecSqlQry(sql_price, GlobalVar.loginSet.warrantassistant45);

                        double spot = 0;
                        foreach (DataRow dr in dt_price.Rows)
                        {
                            spot = Convert.ToDouble(dr["MPrice"].ToString());
                        }

                        if (subwname.EndsWith("購") || subwname.EndsWith("牛"))//如果是Call  要考慮Put=0的情況 
                        {
                            if (IsSpecial.Contains(underlyingID))
                            {
                                if (Market30.Contains(underlyingID))//市值前30  DeltaOne*股價<5億
                                {
                                    if (cr * issueNum * spot > 500000)
                                    {

                                        e.Row.Cells["行使比例"].Appearance.BackColor = Color.DimGray;
                                        e.Row.Cells["行使比例"].Appearance.ForeColor = Color.Gold;
                                        e.Row.Cells["行使比例"].ToolTipText = "為風險標的且為市值前30大標的，DeltaOne市值已超過5億\n";
                                    }
                                }
                                else
                                {
                                    if (cr * issueNum * spot > 200000)
                                    {
                                        e.Row.Cells["行使比例"].Appearance.BackColor = Color.DimGray;
                                        e.Row.Cells["行使比例"].Appearance.ForeColor = Color.Gold;
                                        e.Row.Cells["行使比例"].ToolTipText = "為風險標的 DeltaOne市值已超過2億\n";
                                    }
                                }
                            }
                        }
                        if (subwname.EndsWith("售") || subwname.EndsWith("熊"))
                        {
                            if (IsSpecial.Contains(underlyingID))
                            {
                                if (Market30.Contains(underlyingID))//市值前30  DeltaOne*股價<5億
                                {
                                    if (cr * issueNum * spot > ISTOP30MaxIssue)
                                    {
                                        e.Row.Cells["行使比例"].Appearance.BackColor = Color.DimGray;
                                        e.Row.Cells["行使比例"].Appearance.ForeColor = Color.Gold;
                                        e.Row.Cells["行使比例"].ToolTipText = $@"為風險標的且為市值前30大標的，DeltaOne市值已超過{(int)(ISTOP30MaxIssue / 100000)}億\n";
                                    }
                                }
                                else
                                {
                                    if (cr * issueNum * spot > NonTOP30MaxIssue)
                                    {
                                        e.Row.Cells["行使比例"].Appearance.BackColor = Color.DimGray;
                                        e.Row.Cells["行使比例"].Appearance.ForeColor = Color.Gold;
                                        e.Row.Cells["行使比例"].ToolTipText = $@"為風險標的 DeltaOne市值已超過{(int)(NonTOP30MaxIssue / 100000)}億\n";
                                    }
                                }
                            }
                            if(IsSpecial.Contains(underlyingID) && (double)UidDeltaOne[underlyingID].KgiCallDeltaOne / (double)UidDeltaOne[underlyingID].KgiPutDeltaOne < SpecialCallPutRatio)
                            {
                                e.Row.Cells["行使比例"].Appearance.BackColor = Color.DimGray;
                                e.Row.Cells["行使比例"].Appearance.ForeColor = Color.Gold;
                                e.Row.Cells["行使比例"].ToolTipText += $@"為風險標的，自家權證 Call/Put DeltaOne比例 < {SpecialCallPutRatio}\n";
                            }
                            else if ((double)UidDeltaOne[underlyingID].KgiCallDeltaOne / (double)UidDeltaOne[underlyingID].KgiPutDeltaOne < NonSpecialCallPutRatio)
                            {
                                if (!IsIndex.Contains(underlyingID))
                                {
                                    e.Row.Cells["行使比例"].Appearance.BackColor = Color.DimGray;
                                    e.Row.Cells["行使比例"].Appearance.ForeColor = Color.Gold;
                                    e.Row.Cells["行使比例"].ToolTipText += $@"自家權證 Call/Put DeltaOne比例 < {NonSpecialCallPutRatio}\n";
                                }

                            }
                            if (IsSpecial.Contains(underlyingID) && UidDeltaOne[underlyingID].AllPutDeltaOne > 0 && UidDeltaOne[underlyingID].KgiAllPutRatio > SpecialKGIALLPutRatio)
                            {
                                //若之前這檔標的沒發過Put可以跳過，可是要考慮今天發超過一檔
                                if (UidDeltaOne[underlyingID].KgiPutNum > 1)
                                {
                                    e.Row.Cells["行使比例"].Appearance.BackColor = Color.DimGray;
                                    e.Row.Cells["行使比例"].Appearance.ForeColor = Color.Gold;
                                    e.Row.Cells["行使比例"].ToolTipText += $@"自家/市場 Put DeltaOne比例 > {SpecialKGIALLPutRatio}\n";
                                }
                            }
                        }
                    }

                }
            }
            
            if ((DateTime.Now.TimeOfDay.TotalMinutes >= 660) && dt_record.ContainsKey(serialNum))
            {//11點後再變顏色
                foreach (string key in sqlTogrid.Keys)
                {

                    if (dt_record[serialNum].ContainsKey(sqlTogrid[key]))
                    {
                        //if (key != "行使比例" && e.Row.Cells[key].Appearance.BackColor != Color.DimGray)
                        {
                            e.Row.Cells[key].Appearance.BackColor = Color.LightPink;
                            e.Row.Cells[key].ToolTipText += "(" + dt_record[serialNum][sqlTogrid[key]] + " BY " + dt_recordByTrader[serialNum] + ")";
                        }
                    }
                }
            }
            
        }

        private void ultraGrid1_AfterCellUpdate(object sender, CellEventArgs e) {
            if (e.Cell.Column.Key != "交易員" && e.Cell.Column.Key != "權證名稱" && e.Cell.Column.Key != "發行價格" && e.Cell.Column.Key != "標的代號" && e.Cell.Column.Key != "市場" && e.Cell.Column.Key != "1500W") {
                double price = 0.0;

                double underlyingPrice = 0.0;
                underlyingPrice = e.Cell.Row.Cells["股價"].Value == DBNull.Value ? 0 : Convert.ToDouble(e.Cell.Row.Cells["股價"].Value);
                double k = 0.0;
                k = e.Cell.Row.Cells["履約價"].Value == DBNull.Value ? 0 : Convert.ToDouble(e.Cell.Row.Cells["履約價"].Value);
                int t = 0;
                t = e.Cell.Row.Cells["期間"].Value == DBNull.Value ? 0 : Convert.ToInt32(e.Cell.Row.Cells["期間"].Value);
                double cr = 0.0;
                cr = e.Cell.Row.Cells["行使比例"].Value == DBNull.Value ? 0 : Convert.ToDouble(e.Cell.Row.Cells["行使比例"].Value);
                double vol = 0.0;
                vol = e.Cell.Row.Cells["IV"].Value == DBNull.Value ? 0 : Convert.ToDouble(e.Cell.Row.Cells["IV"].Value) / 100;
                double resetR = 0.0;
                resetR = e.Cell.Row.Cells["重設比"].Value == DBNull.Value ? 0 : Convert.ToDouble(e.Cell.Row.Cells["重設比"].Value) / 100;
                double financialR = 0.0;
                financialR = e.Cell.Row.Cells["財務費用"].Value == DBNull.Value ? 0 : Convert.ToDouble(e.Cell.Row.Cells["財務費用"].Value) / 100;
                string warrantType = "一般型";
                warrantType = e.Cell.Row.Cells["類型"].Value == DBNull.Value ? "一般型" : e.Cell.Row.Cells["類型"].Value.ToString();
                string cpType = "C";
                cpType = e.Cell.Row.Cells["CP"].Value == DBNull.Value ? "C" : e.Cell.Row.Cells["CP"].Value.ToString();

                if (warrantType != "一般型" && warrantType != "牛熊證" && warrantType != "重設型") {
                    if (warrantType == "2")
                        warrantType = "牛熊證";
                    else if (warrantType == "3")
                        warrantType = "重設型";
                    else
                        warrantType = "一般型";
                }

                if (cpType != "C" && cpType != "P") {
                    if (cpType == "2")
                        cpType = "P";
                    else
                        cpType = "C";
                }

                CallPutType cp = CallPutType.Call;
                if (cpType == "P")
                    cp = CallPutType.Put;
                else
                    cp = CallPutType.Call;

                if (warrantType == "牛熊證")
                    price = Pricing.BullBearWarrantPrice(cp, underlyingPrice, resetR, GlobalVar.globalParameter.interestRate, vol, t, financialR, cr);
                else if (warrantType == "重設型")
                    price = Pricing.ResetWarrantPrice(cp, underlyingPrice, resetR, GlobalVar.globalParameter.interestRate, vol, t, cr);
                else
                    price = Pricing.NormalWarrantPrice(cp, underlyingPrice, k, GlobalVar.globalParameter.interestRate, vol, t, cr);

                /*e.Cell.Row.Cells["履約價"].Appearance.ForeColor = Color.Black;
                if (warrantType != "牛熊證") {
                    if (cpType == "C" && k / underlyingPrice >= 1.5) {
                        e.Cell.Row.Cells["履約價"].Appearance.ForeColor = Color.Red;
                    } else if (cpType == "P" && k / underlyingPrice <= 0.5) {
                        e.Cell.Row.Cells["履約價"].Appearance.ForeColor = Color.Red;
                    }
                }*/

                double shares = 0.0;
                shares = e.Cell.Row.Cells["張數"].Value == DBNull.Value ? 10000 : Convert.ToDouble(e.Cell.Row.Cells["張數"].Value);
                /*
                string is1500W = "N";
                is1500W = e.Cell.Row.Cells["1500W"].Value == DBNull.Value ? "N" : (string)e.Cell.Row.Cells["1500W"].Value;
                if (e.Cell.Column.Key == "1500W" && is1500W=="Y")
                {
                    double totalValue = 0.0;
                    totalValue = price * shares * 1000;
                    while (totalValue < 15000000)
                    {
                        vol += 0.01;
                        if (warrantType == "牛熊證")
                            price = Pricing.BullBearWarrantPrice(cp, underlyingPrice, resetR, GlobalVar.globalParameter.interestRate, vol, t, financialR, cr);
                        else if (warrantType == "重設型")
                            price = Pricing.ResetWarrantPrice(cp, underlyingPrice, resetR, GlobalVar.globalParameter.interestRate, vol, t, cr);
                        else
                            price = Pricing.NormalWarrantPrice(cp, underlyingPrice, k, GlobalVar.globalParameter.interestRate, vol, t, cr);
                        totalValue = price * shares * 1000;
                    }
                    e.Cell.Row.Cells["IV"].Value = Math.Round(vol * 100, 0);
                }
                 * */

                e.Cell.Row.Cells["發行價格"].Value = Math.Round(price, 2);
            }

            string is1500W = "N";
            is1500W = e.Cell.Row.Cells["1500W"].Value.ToString();
            if (e.Cell.Column.Key == "1500W") {
                if (is1500W == "N")
                    e.Cell.Row.Cells["IV"].Value = e.Cell.Row.Cells["IVOri"].Value;
            }
        }

        private void ultraGrid1_DoubleClickCell(object sender, DoubleClickCellEventArgs e) {
            if (e.Cell.Column.Key == "標的代號")
                GlobalUtility.MenuItemClick<FrmIssueCheck>().SelectUnderlying((string) e.Cell.Value);

            if (e.Cell.Column.Key == "CP")
                GlobalUtility.MenuItemClick<FrmIssueCheckPut>().SelectUnderlying((string) e.Cell.Row.Cells["標的代號"].Value);
        }
    }
}
